/*
*******************************************************************************
Product     : Common Resource
File        : common.h
Description : This is the commom header to be used by all components and modules.
*/

#ifndef COMMON
#define COMMON

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */
 
/* Data type definitions */
typedef signed char          Int8;
typedef unsigned char        Uint8;
typedef short int            Int16;
typedef unsigned short int   Uint16;
typedef int                  Int32;
typedef unsigned int         Uint32;

typedef float                Flt32;
typedef double               Flt64;

typedef unsigned char        Bool;
typedef signed int           Error;


#define TRUE               1
#define FALSE              0

#define ON                 1
#define OFF                0

/* Common error code definitions */
#define SUCCESS            0
#define FAILURE           (-1)
#define OUT_OF_MEMORY     (-2)
#define INVALID_ARGS      (-3)
#define NOT_SUPPORTED     (-4)

#ifdef __cplusplus
}
#endif  /*__cplusplus */

#endif  /* COMMON */

