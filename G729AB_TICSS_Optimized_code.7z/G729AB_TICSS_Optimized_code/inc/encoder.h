/*
*******************************************************************************
Product     : ITU-T G.729A  8 kbit/s (G729 AB) codec.
Module      : Encoder
File        : encoder.h
Description : declaration of encoder object
*/

#ifndef ENCODER
#define ENCODER

#include "common_enc.h"
#include "includes.h"

#ifdef G729AB_ENCODER_ONLY

typedef struct G729AB_Encoder G729ABEncoder;

struct G729AB_Encoder
{
	/* Function pointer to encode a frame */
	Int32  (*EncodeFrame) (SpeechEncoder *g729abcontext,
							Int16* srcBuf, 
							Int32  scrLen, 
							Int16* dstBuf,
							Int32* dstLen);

    /* Function Ptr to reset the encoder */
	Int32 (*Reset) (SpeechEncoder *g729abcontext);
	/* Function ptr to get a specified parameter value */
    void (*Delete) (SpeechEncoder *g729abcontext);

	G729ABEncoderStaticStruct *EncStaticStruct;
};

Int32 CreateG729ABEncoder(SpeechEncoder **g729abcontext);

#endif  // #ifdef G729AB_ENCODER_ONLY
#endif
