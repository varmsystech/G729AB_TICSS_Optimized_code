/* ITU-T G.729 Software Package Release 2 (November 2006) */
/*
   ITU-T G.729A Annex B     ANSI-C Source Code
   Version 1.3    Last modified: August 1997
   Copyright (c) 1996, France Telecom, Rockwell International,
                       Universite de Sherbrooke.
   All rights reserved.
*/


#include "includes.h"
#ifdef G729AB_ENCODER_ONLY


void vad_init(G729ABEncoderVADStruct *VADStruct);

void vad(
		 G729ABEncoderVADStruct *VADStruct,
         Word16 rc,
         Word16 *lsf, 
         Word16 *r_h,
         Word16 *r_l,
         Word16 exp_R0,
         Word16 *sigpp,
         Word16 frm_count,
         Word16 prev_marker,
         Word16 pprev_marker,
         Word16 *marker);

#endif









