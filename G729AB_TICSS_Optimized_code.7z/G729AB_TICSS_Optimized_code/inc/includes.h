/*
*******************************************************************************
Product     : ITU-T G.729A  8 kbit/s (G729 AB) codec.
Module      : Encoder
File        : includes.h
Description : all include files
*/


#ifndef INCLUDES
#define INCLUDES

#include "common.h"

#define  STACK_ARRAY_SIZE_ENC  780  /* controls the size of stack_array= size* 4 */
#define  STACK_ARRAY_SIZE_DEC  170  /* controls the size of stack_array= size* 4 */
#define  L_TOTAL      240     /* Total size of speech buffer.               */
#define  L_WINDOW     240     /* Window size in LP analysis.                */
#define  L_NEXT       40      /* Lookahead in LP analysis.                  */
#define  L_FRAME      80      /* Frame size.                                */
#define  L_SUBFR      40      /* Subframe size.                             */
#define  M            10      /* Order of LP filter.                        */
#define  MP1          (M+1)   /* Order of LP filter + 1                     */
#define  PIT_MIN      20      /* Minimum pitch lag.                         */
#define  PIT_MAX      143     /* Maximum pitch lag.                         */
#define  L_INTERPOL   (10+1)  /* Length of filter for interpolation.        */
#define  GAMMA1       24576   /* Bandwitdh factor = 0.75   in Q15           */

#define  SERIAL_SIZE  (80+2)  /* bfi+ number of speech bits                 */

#define SHARPMAX  13017   /* Maximum value of pitch sharpening     0.8  Q14 */
#define SHARPMIN  3277    /* Minimum value of pitch sharpening     0.2  Q14 */

#define NCODE1_B  3                /* number of Codebook-bit */
#define NCODE2_B  4                /* number of Codebook-bit */
#define NCODE1    (1<<NCODE1_B)    /* Codebook 1 size */
#define NCODE2    (1<<NCODE2_B)    /* Codebook 2 size */
#define NCAN1     4                /* Pre-selecting order for #1 */
#define NCAN2     8                /* Pre-selecting order for #2 */
#define INV_COEF  -17103           /* Q19 */

#define BIT_0     (short)0x007f /* definition of zero-bit in bit-stream      */
#define BIT_1     (short)0x0081 /* definition of one-bit in bit-stream       */
#define SYNC_WORD (short)0x6b21 /* definition of frame erasure flag          */
#define SIZE_WORD (short)80     /* number of speech bits                     */


/*-----------------------------------*
 * Post-filter functions.            *
 *-----------------------------------*/

#define L_H 22     /* size of truncated impulse response of A(z/g1)/A(z/g2) */

#define GAMMAP      16384   /* 0.5               (Q15) */
#define INV_GAMMAP  21845   /* 1/(1+GAMMAP)      (Q15) */
#define GAMMAP_2    10923   /* GAMMAP/(1+GAMMAP) (Q15) */

#define  GAMMA2_PST 18022 /* Formant postfilt factor (numerator)   0.55 Q15 */
#define  GAMMA1_PST 22938 /* Formant postfilt factor (denominator) 0.70 Q15 */

#define  MU       26214   /* Factor for tilt compensation filter   0.8  Q15 */
#define  AGC_FAC  29491   /* Factor for automatic gain control     0.9  Q15 */
#define  AGC_FAC1 (short)(32767 - AGC_FAC)    /* 1-AGC_FAC in Q15          */

/*--------------------------------------------------------------------------*
 * Constants and prototypes for taming procedure.                           *
 *--------------------------------------------------------------------------*/

#define GPCLIP      15564      /* Maximum pitch gain if taming is needed Q14*/
#define GPCLIP2     481        /* Maximum pitch gain if taming is needed Q9 */
#define GP0999      16383      /* Maximum pitch gain if taming is needed    */
#define L_THRESH_ERR 983040000L /* Error threshold taming 16384. * 60000.   */

#define  AUTO_CORR_TESTING
#define  LPC_TESTING
#define  PITCH_TESTING
#define  CMP_FILT_TESTING
#define  DEC_TESTING

/*--------------------------------------------------------------------------*
 *       LSP constant parameters                                            *
 *--------------------------------------------------------------------------*/

#define   NC            5      /*  NC = M/2 */
#define   MA_NP         4      /* MA prediction order for LSP */
#define   MODE          2      /* number of modes for MA prediction */
#define   NC0_B         7      /* number of first stage bits */
#define   NC1_B         5      /* number of second stage bits */
#define   NC0           (1<<NC0_B)
#define   NC1           (1<<NC1_B)

#define   L_LIMIT          40   /* Q13:0.005 */
#define   M_LIMIT       25681   /* Q13:3.135 */

#define   GAP1          10     /* Q13 */
#define   GAP2          5      /* Q13 */
#define   GAP3          321    /* Q13 */
#define GRID_POINTS     50

#define PI04      ((short)1029)        /* Q13  pi*0.04 */
#define PI92      ((short)23677)       /* Q13  pi*0.92 */
#define CONST10   ((short)10*(1<<11))  /* Q11  10.0 */
#define CONST12   ((short)19661)       /* Q14  1.2 */

/*-----------------------*
 * Innovative codebook.  *
 *-----------------------*/

#define DIM_RR  616 /* size of correlation matrix                            */
#define NB_POS  8   /* Number of positions for each pulse                    */
#define STEP    5   /* Step betweem position of the same pulse.              */
#define MSIZE   64  /* Size of vectors for cross-correlation between 2 pulses*/

/* The following constants are Q15 fractions.
   These fractions is used to keep maximum precision on "alp" sum */

#define _1_2    (short)(16384)
#define _1_4    (short)( 8192)
#define _1_8    (short)( 4096)
#define _1_16   (short)( 2048)

/*--------------------------------------------------------------------------*
 *       LTP constant parameters                                            *
 *--------------------------------------------------------------------------*/

#define UP_SAMP         3
#define L_INTER10       10
#define FIR_SIZE_SYN    (UP_SAMP*L_INTER10+1)

#define     NP            12                  /* Increased LPC order */
#define     NOISE         0
#define     VOICE         1
#define     INIT_FRAME    32
#define     INIT_COUNT    20
#define     ZC_START      120
#define     ZC_END        200

#define         TRUE 1
#define         FALSE 0
#define         sqr(a)  ((a)*(a))
#define         R_LSFQ 10
#define OCTET_TX_MODE
#define RATE_SID_OCTET    16     /* number of bits in Octet Transmission mode */

/* DTX constants */
#define FLAG_COD        (Flag)1
#define FLAG_DEC        (Flag)0
#define INIT_SEED       11111
#define FR_SID_MIN      3
#define NB_SUMACF       3
#define NB_CURACF       2
#define NB_GAIN         2
#define FRAC_THRESH1    4855
#define FRAC_THRESH2    3161
#define A_GAIN0         28672

#define SIZ_SUMACF      (NB_SUMACF * MP1)
#define SIZ_ACF         (NB_CURACF * MP1)
#define A_GAIN1         4096    /* 32768L - A_GAIN0 */

#define RATE_8000       80      /* Full rate  (8000 bit/s)       */
#define RATE_SID        15      /* SID                           */
#define RATE_0           0      /* 0 bit/s rate                  */

/* CNG excitation generation constant */
                                        /* alpha = 0.5 */
#define FRAC1           19043           /* (sqrt(40)xalpha/2 - 1) * 32768 */
#define K0              24576           /* (1 - alpha ** 2) in Q15        */
#define G_MAX           5000

typedef struct G729ABEncoderDTXStruct
{
	/* Static Variables */
	Int16 lspSid_q[M] ;
	Int16 pastCoeff[MP1];
	Int16 RCoeff[MP1];
	Int16 sh_RCoeff;
	Int16 Acf[SIZ_ACF];
	Int16 sh_Acf[NB_CURACF];
	Int16 sumAcf[SIZ_SUMACF];
	Int16 sh_sumAcf[NB_SUMACF];
	Int16 ener[NB_GAIN];
	Int16 sh_ener[NB_GAIN];
	Int16 fr_cur;
	Int16 cur_gain;
	Int16 nb_ener;
	Int16 sid_gain;
	Int16 flag_chang;
	Int16 prev_energy;
	Int16 count_fr0;
}G729ABEncoderDTXStruct;

typedef struct PrePostProcessStaticStruct
{
	Int16 y2_hi;
	Int16 y2_lo;
	Int16  y1_hi;
	Int16 y1_lo;
	Int16 x0;
	Int16 x1;
}tPrePostProcessStaticStruct;

typedef struct tPostFilterStaticStruct
{
	Int16 res2_buf[PIT_MAX+L_SUBFR];
	Int16 scal_res2_buf[PIT_MAX+L_SUBFR];
	//Int16 mem_syn_pst[M];
    Int32 mem_syn_pst_buf[(M/2)];
    Int16 *mem_syn_pst;
	Int16 *res2;
	Int16 *scal_res2;
	Int16 mem_pre;
}tPostFilterStaticStruct;


typedef struct G729ABEncoderVADStruct
{
	Int16 MeanLSF[M];
	Int16 Min_buffer[16];
	Int16 Prev_Min;
	Int16 Next_Min;
	Int16 Min;
	Int16 MeanE;
	Int16 MeanSE;
	Int16 MeanSLE;
	Int16 MeanSZC;
	Int16 prev_energy;
	Int16 count_sil;
	Int16 count_update;
	Int16 count_ext;
	Int16 flag;
	Int16 v_flag;
	Int16 less_count;
}G729ABEncoderVADStruct;


typedef struct G729ABEncoderStaticStruct
{
	Int16 frame;
	Int16 vad_enable;
    /* Speech vector */
    Int32 old_speech_buffer[(L_TOTAL/2)];
    Int32 old_exc_buffer[((L_FRAME+PIT_MAX+L_INTERPOL)/2)];
    Int32 memmory_buffer[((M+M+M)/2)];
    Int32 old_wsp_buffer[(L_FRAME+PIT_MAX+1)/2];
    
	//Int16 old_speech[L_TOTAL];
	Int16 *old_speech;
	Int16 *new_speech;
	Int16 *speech;
	Int16 *p_window;
	/* Weighted speech vector */
	//Int16 old_wsp[L_FRAME+PIT_MAX+1];
	Int16 *old_wsp;
	
	Int16 *wsp;
	/* Excitation vector */
	//Int16 old_exc[L_FRAME+PIT_MAX+L_INTERPOL];
	Int16 *old_exc;
	
	Int16 *exc;
	/* Lsp (Line spectral pairs) */
	Int16 lsp_old[M];
	Int16 lsp_old_q[M];
		/* Filter's memory */
	//Int16 mem_w0[M];
	//Int16 mem_w[M];
	//Int16 mem_zero[M];
	Int16 *mem_w0;
	Int16 *mem_w;
	Int16 *mem_zero;
	Int16  sharp;
		/* For G.729B */
		/* DTX variables */
	Int16 pastVad;   
	Int16 ppastVad;
	Int16 seed;	
	
	Int16 old_A[M+1];
	Int16 old_rc[2];

	Int16 past_qua_en[4]; 
	Int16 freq_prev[MA_NP][M];    /* Q13:previous LSP vector       */

	Int32 L_exc_err[4];
	Int32 stack_array[STACK_ARRAY_SIZE_ENC];
	
	G729ABEncoderDTXStruct DTXStruct;
	G729ABEncoderVADStruct VADStruct;
	tPrePostProcessStaticStruct PreProStruct;
	
	}G729ABEncoderStaticStruct;

typedef struct G729ABDecoderStaticStruct
{
	
    Int32 stack_array[STACK_ARRAY_SIZE_DEC];

	Int16 synth_buf[L_FRAME+M];
	Int16 old_exc[L_FRAME+PIT_MAX+L_INTERPOL+1];
	
	
	/* Lsp (Line spectral pairs) */
	Int16 lsp_old[M];/*={
			 30000, 26000, 21000, 15000, 8000, 0, -8000,-15000,-21000,-26000};*/
	Int16 *mem_syn;
    Int32 mem_syn_buf[(M/2)];
	//Int16 *mem_syn;
	Int16 lspSid[M];
	Int16 freq_prev[MA_NP][M];   /* Q13 */
	Int16 prev_lsp[M];              /* previous LSP vector         */
	
	Int32 L_exc_err[4];
	Int16 *exc;
	Int16 *synth; /* Synthesis                   */
	Int16 bad_lsf;        /* bad LSF indicator   */
	/* Filter's memory */
	
	Int16 sharp;           /* pitch sharpening of previous frame */
	Int16 old_T0;          /* integer delay of previous frame    */
	Int16 gain_code;       /* Code gain                          */
	Int16 gain_pitch;      /* Pitch gain                         */
	/* for G.729B */
	Int16 seed_fer;
	/* CNG variables */
	Int16 past_ftyp;
	Int16 seed;
	Int16 sid_sav;
	Int16 sh_sid_sav;   
	Int16 past_qua_en[4];
	Int16 cur_gain;
	
	Int16 sid_gain;

	
	/* static memory for frame erase operation */
	Int16 prev_ma;                  /* previous MA prediction coef.*/
	

	
    
	tPrePostProcessStaticStruct PostProStruct;
	tPostFilterStaticStruct PostFilterStruct;
	
	
}G729ABDecoderStaticStruct;

#include "stdlib.h"
#include "stdio.h"
#include "string.h"

#include "codec_api.h"
#include "encoder.h"
#include "decoder.h"
#include "typedef.h"
#include "basic_op.h"
#include "ld8a.h"
#include "dtx.h"

#include "oper_32b.h"
#include "sid.h"
#include "tab_ld8a.h"
#include "vad.h"



#endif













