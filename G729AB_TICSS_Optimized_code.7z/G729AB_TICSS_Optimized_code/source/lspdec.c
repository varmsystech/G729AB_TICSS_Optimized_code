/*
   ITU-T G.729A Speech Coder with Annex B    ANSI-C Source Code
   Version 1.3    Last modified: August 1997

   Copyright (c) 1996,
   AT&T, France Telecom, NTT, Universite de Sherbrooke, Lucent Technologies,
   Rockwell International
   All rights reserved.
*/

#include "typedef.h"
#include "ld8a.h"
#include "basic_op.h"
#include "tab_ld8a.h"

/* static memory */



#ifdef  G729AB_DECODER_ONLY
/*----------------------------------------------------------------------------
 * Lsp_decw_reset -   set the previous LSP vectors
 *----------------------------------------------------------------------------
 */
void Lsp_decw_reset(G729ABDecoderStaticStruct *G729ABDec)
{
  Word16 i;
#if 1
  for(i=0; i<MA_NP; i++)
  	Copy( &freq_prev_reset[0], &G729ABDec->freq_prev[i][0], M );
#else
  	Copy( &freq_prev_reset[0], &G729ABDec->freq_prev[0][0], M*MA_NP);    
#endif


  G729ABDec->prev_ma = 0;

  Copy( freq_prev_reset, G729ABDec->prev_lsp, M);
}



/*----------------------------------------------------------------------------
 * Lsp_iqua_cs -  LSP main quantization routine
 *----------------------------------------------------------------------------
 */
void Lsp_iqua_cs(
 G729ABDecoderStaticStruct *G729ABDec,
 Word16 prm[],          /* (i)     : indexes of the selected LSP */
 Word16 lsp_q[],        /* (o) Q13 : Quantized LSP parameters    */
 Word16 erase,           /* (i)     : frame erase information     */
 Word32 *Scratch_Mem
)
{
  Word16 mode_index;
  Word16 code0;
  Word16 code1;
  Word16 code2;
  //Word16 buf[M];     /* Q13 */

  Word16 *buf = (Word16 *)(Scratch_Mem);
  Word32 *Scratch_Mem1= (Word32 *)(buf+M); 

  if( erase==0 ) 
  {  /* Not frame erasure */
    mode_index = shr(prm[0] ,NC0_B) & (Word16)1;
    code0 = prm[0] & (Word16)(NC0 - 1);
    code1 = shr(prm[1] ,NC1_B) & (Word16)(NC1 - 1);
    code2 = prm[1] & (Word16)(NC1 - 1);

    /* compose quantized LSP (lsp_q) from indexes */
  
    Lsp_get_quant(lspcb1, lspcb2, code0, code1, code2,
      fg[mode_index], G729ABDec->freq_prev, lsp_q, fg_sum[mode_index],
      Scratch_Mem1);

    /* save parameters to use in case of the frame erased situation */

    Copy(lsp_q, G729ABDec->prev_lsp, M);
    G729ABDec->prev_ma = mode_index;
  }
  else 
  {           /* Frame erased */
    /* use revious LSP */

    Copy(G729ABDec->prev_lsp, lsp_q, M);

    /* update G729ABDec->freq_prev */

    Lsp_prev_extract(G729ABDec->prev_lsp, buf,
      fg[G729ABDec->prev_ma], G729ABDec->freq_prev, fg_sum_inv[G729ABDec->prev_ma]);
    Lsp_prev_update(buf, G729ABDec->freq_prev);
  }

  return;
}



/*-------------------------------------------------------------------*
 * Function  D_lsp:                                                  *
 *           ~~~~~~                                                  *
 *-------------------------------------------------------------------*/

void D_lsp(
  G729ABDecoderStaticStruct *G729ABDec,
  Word16 prm[],          /* (i)     : indexes of the selected LSP */
  Word16 lsp_q[],        /* (o) Q15 : Quantized LSP parameters    */
  Word16 erase,           /* (i)     : frame erase information     */
  Word32 *Scratch_Mem
)
{
  
  //Word16 lsf_q[M];       /* domain 0.0<= lsf_q <PI in Q13 */
  
  Word16 *lsf_q = (Word16*)(Scratch_Mem);
  Word32 *Scratch_Mem1 =(Word32 *)(lsf_q+M);


  Lsp_iqua_cs(G729ABDec,prm, lsf_q, erase,Scratch_Mem1);

  /* Convert LSFs to LSPs */

  Lsf_lsp2(lsf_q, lsp_q, M);

  return;
}

void Get_decfreq_prev(Int16 freq_prev[MA_NP][M],
									  Word16 x[MA_NP][M])
{
    Copy(&freq_prev[0][0], &x[0][0], M*MA_NP);
}
  
void Update_decfreq_prev(Int16 freq_prev[MA_NP][M],
										 Word16 x[MA_NP][M])
{
    Copy(&x[0][0], &freq_prev[0][0], M*MA_NP);
}
#endif  //#ifdef  G729AB_DECODER_ONLY



