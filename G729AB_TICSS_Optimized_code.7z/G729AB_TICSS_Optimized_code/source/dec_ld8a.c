/* ITU-T G.729 Software Package Release 2 (November 2006) */
/*
   ITU-T G.729A Speech Coder with Annex B    ANSI-C Source Code
   Version 1.5    Last modified: October 2006 

   Copyright (c) 1996,
   AT&T, France Telecom, NTT, Universite de Sherbrooke, Lucent Technologies,
   Rockwell International
   All rights reserved.
*/

/*-----------------------------------------------------------------*
 *   Functions Init_Decod_ld8a  and Decod_ld8a                     *
 *-----------------------------------------------------------------*/

#include "includes.h"
#ifdef G729AB_DECODER_ONLY
/*---------------------------------------------------------------*
 *   Decoder constant parameters (defined in "ld8a.h")           *
 *---------------------------------------------------------------*
 *   L_FRAME     : Frame size.                                   *
 *   L_SUBFR     : Sub-frame size.                               *
 *   M           : LPC order.                                    *
 *   MP1         : LPC order+1                                   *
 *   PIT_MIN     : Minimum pitch lag.                            *
 *   PIT_MAX     : Maximum pitch lag.                            *
 *   L_INTERPOL  : Length of filter for interpolation            *
 *   PRM_SIZE    : Size of vector containing analysis parameters *
 *---------------------------------------------------------------*/

/*--------------------------------------------------------*
 *         Static memory allocation.                      *
 *--------------------------------------------------------*/

        /* Excitation vector */

 



/*-----------------------------------------------------------------*
 *   Function Init_Decod_ld8a                                      *
 *            ~~~~~~~~~~~~~~~                                      *
 *                                                                 *
 *   ->Initialization of variables for the decoder section.        *
 *                                                                 *
 *-----------------------------------------------------------------*/


void Init_Decod_ld8a(G729ABDecoderStaticStruct *G729ABDec)
{

  G729ABDec->bad_lsf = 0;
  Set_zero(G729ABDec->synth_buf,M);

  G729ABDec->synth = G729ABDec->synth_buf + M;
  /* Initialize static pointer */

  G729ABDec->mem_syn = (Word16 *)G729ABDec->mem_syn_buf;
  G729ABDec->exc = G729ABDec->old_exc + PIT_MAX + L_INTERPOL;

  /* Static vectors to zero */

  Set_zero(G729ABDec->old_exc, PIT_MAX+L_INTERPOL);
  Set_zero(G729ABDec->mem_syn, M);

  G729ABDec->sharp  = SHARPMIN;
  G729ABDec->old_T0 = 60;
  G729ABDec->gain_code = 0;
  G729ABDec->gain_pitch = 0;

  Copy((Int16*)lspoldinit,G729ABDec->lsp_old, M);
  Lsp_decw_reset(G729ABDec);

  /* for G.729B */
  G729ABDec->seed_fer = 21845;
  G729ABDec->past_ftyp = 1;
  G729ABDec->seed = INIT_SEED;
  G729ABDec->sid_sav = 0;
  G729ABDec->sh_sid_sav = 1;
  Init_lsfq_noise();

  G729ABDec->past_qua_en[0] = -14336;
  G729ABDec->past_qua_en[1] = -14336;
  G729ABDec->past_qua_en[2] = -14336;
  G729ABDec->past_qua_en[3] = -14336;

  return;
}

/*-----------------------------------------------------------------*
 *   Function Decod_ld8a                                           *
 *           ~~~~~~~~~~                                            *
 *   ->Main decoder routine.                                       *
 *                                                                 *
 *-----------------------------------------------------------------*/

void Decod_ld8a(
  G729ABDecoderStaticStruct *G729ABDec,
  Word16  parm[],      /* (i)   : vector of synthesis parameters
                                  parm[0] = bad frame indicator (bfi)  */
  Word16  synth[],     /* (o)   : synthesis speech                     */
  Word16  A_t[],       /* (o)   : decoded LP filter in 2 subframes     */
  Word16  *T2,         /* (o)   : decoded pitch lag in 2 subframes     */
  Word16  *Vad,         /* (o)   : frame type                           */
  Word32  *Scratch_Mem
)
{
  Word16  *Az;                  /* Pointer on A_t   */
  

  /* Scalars */

  Word16  i, j, i_subfr;
  Word16  T0, T0_frac, index;
  Word16  bfi;
  Word32  L_temp;

  Word16 bad_pitch;             /* bad pitch indicator */
  /* for G.729B */
  Word16 ftyp;
  
  
  
  
  Word16 i_test, j_test;
  Word32 s_test;
  
  Word16 *yy_test;
  Word32 s1_test,s2_test,s3_test;
			
  Word16 *a_test,*x_test,*y_test;
  Word32 Over_fl;

  
  
  Word32 Overflow_check;

 
  Word32 *Scratch_Mem1; 
  Word16 (*lsfq_mem)[M];
  Word16  *lsp_new  =   (Word16 *)(Scratch_Mem);
  Word16  *code     =   (Word16 *)(lsp_new + M);       // Word16  lsp_new[M];
  Scratch_Mem1      =   (Word32 *)(code +L_SUBFR);      // Word16  code[L_SUBFR];
  lsfq_mem 			=   (Word16 (*)[M])(Scratch_Mem1);
  Scratch_Mem1		=   (Word32 *)(Scratch_Mem1+((MA_NP*M)>>1)); // lsfq_mem[MA_NP][M]
  
 
  /* Test bad frame indicator (bfi) */

  bfi = *parm++;
  /* for G.729B */
  ftyp = *parm;

  if(bfi == 1) 
  {
    if(G729ABDec->past_ftyp == 1) ftyp = 1;
    else ftyp = 0;
    *parm = ftyp;  /* modification introduced in version V1.3 */
  }
  
  *Vad = ftyp;

  /* Processing non active frames (SID & not transmitted) */
  if(ftyp != 1) 
  {
    
    Get_decfreq_prev(G729ABDec->freq_prev,lsfq_mem);

    Dec_cng(G729ABDec,G729ABDec->past_ftyp, G729ABDec->sid_sav, G729ABDec->sh_sid_sav, parm, G729ABDec->exc, G729ABDec->lsp_old,
            A_t, &G729ABDec->seed, lsfq_mem,Scratch_Mem1);
            
    Update_decfreq_prev(G729ABDec->freq_prev,lsfq_mem);

    Az = A_t;
    /*----------------------------------------------------------------*/
    for (i_subfr = 0; i_subfr < L_FRAME; i_subfr += L_SUBFR) 
	{
      

	  /*------------------------------------------------------------------*/
           Over_fl=0;


			
			 a_test=Az;
             x_test=&G729ABDec->exc[i_subfr];
             y_test=&synth[i_subfr];

				/* Copy mem[] to yy[] */


                yy_test = (Word16 *)Scratch_Mem1;
				 

				Copy(G729ABDec->mem_syn, yy_test, M);
    
				/* Do the filtering. */
                

				for (i_test = 0; i_test <L_SUBFR; i_test++)
				{
                    s_test = L_mult(x_test[i_test], a_test[0]);
				    
					for (j_test = 1; j_test <= M; j_test++)
					{   
						s1_test= s_test;

						s2_test= L_mult(a_test[j_test], yy_test[-j_test+M+i_test]);
						
						 s_test = s1_test - s2_test;

						if (((s1_test ^ s2_test) & MIN_32) != 0)
							{
								if ((s_test ^ s1_test) & MIN_32)
								{
									s_test = (s1_test < 0L) ? MIN_32 : MAX_32;
									Over_fl = 1;
								}
							}

						//s = L_msu(s, a[j], yy[-j]);
					}
                    
					if((s_test>=268435456))
					{
					 Over_fl = 1;
					 s_test=0x7fffffff;
					}
					else if(s_test< -268435456)  /*0xf0000000 */
					{
					  Over_fl = 1;
					  s_test=0x80000000;
					}
					else
					{
					 s_test= s_test << 3;
					
					}
					//s = L_shl(s, 3);
					//if(s_test>=0x7fff8000)
					if(s_test>=2147450880)
					{					 
					 Over_fl=1;
					 s_test=0x7fffffff;
					 yy_test[i_test+M] = (Word16)((s_test+ 32768)>>16);
					}
					else
					{
					 yy_test[i_test+M] = (Word16)((s_test+ 32768)>>16);
					}

					//*yy++ = round(s);
				}
			#if 0
				for(i_test=0; i_test<L_SUBFR; i_test++)
				{
				   y_test[i_test] = yy_test[i_test+M];
				}
			#else
				//above loop is replaced with following function
				Copy(yy_test+M, y_test, L_SUBFR);
			#endif
			
			 /* Update of memory if update==1 */

      if(Over_fl != 0) 
	  {
        /* In case of overflow in the synthesis          */
        /* -> Scale down vector G729ABDec->exc[] and redo synthesis */
        
        	for(i=0; i<PIT_MAX+L_INTERPOL+L_FRAME; i++)
          		G729ABDec->old_exc[i] = shr(G729ABDec->old_exc[i], 2);
        Syn_filt1(Az, &G729ABDec->exc[i_subfr], &synth[i_subfr], L_SUBFR, G729ABDec->mem_syn, 1,Scratch_Mem1);
      }
      else
        Copy(&synth[i_subfr+L_SUBFR-M], G729ABDec->mem_syn, M);
        

      Az += MP1;

      *T2++ = G729ABDec->old_T0;
    }
    /*-----------------------------------------------------------------*/

    G729ABDec->sharp = SHARPMIN;
    
  }
  /* Processing active frame */
  else {
    
    G729ABDec->seed = INIT_SEED;
    parm++;

    /* Decode the LSPs */

    D_lsp(G729ABDec,parm, lsp_new, add(bfi, G729ABDec->bad_lsf),Scratch_Mem1);
    parm += 2;
    
    /*
       Note: "bad_lsf" is introduce in case the standard is used with
       channel protection.
       */
    
    /* Interpolation of LPC for the 2 subframes */

    Int_qlpc(G729ABDec->lsp_old, lsp_new, A_t,Scratch_Mem1);
    
    /* update the LSFs for the next frame */
    
    Copy(lsp_new, G729ABDec->lsp_old, M);
    
    /*------------------------------------------------------------------------*
     *          Loop for every subframe in the analysis frame                 *
     *------------------------------------------------------------------------*
     * The subframe size is L_SUBFR and the loop is repeated L_FRAME/L_SUBFR  *
     *  times                                                                 *
     *     - decode the pitch delay                                           *
     *     - decode algebraic code                                            *
     *     - decode pitch and codebook gains                                  *
     *     - find the excitation and compute synthesis speech                 *
     *------------------------------------------------------------------------*/
    
    Az = A_t;            /* pointer to interpolated LPC parameters */
    
    for (i_subfr = 0; i_subfr < L_FRAME; i_subfr += L_SUBFR)
      {

        index = *parm++;        /* pitch index */

        if(i_subfr == 0)
          {
            i = *parm++;        /* get parity check result */
            bad_pitch = add(bfi, i);
            if( bad_pitch == 0)
              {
                Dec_lag3(index, PIT_MIN, PIT_MAX, i_subfr, &T0, &T0_frac);
                G729ABDec->old_T0 = T0;
              }
            else                /* Bad frame, or parity error */
              {
                T0  =  G729ABDec->old_T0;
                T0_frac = 0;
                G729ABDec->old_T0 = add( G729ABDec->old_T0, 1);
                if( sub(G729ABDec->old_T0, PIT_MAX) > 0) {
                  G729ABDec->old_T0 = PIT_MAX;
                }
              }
          }
        else                    /* second subframe */
          {
            if( bfi == 0)
              {
                Dec_lag3(index, PIT_MIN, PIT_MAX, i_subfr, &T0, &T0_frac);
                G729ABDec->old_T0 = T0;
              }
            else
              {
                T0  =  G729ABDec->old_T0;
                T0_frac = 0;
                G729ABDec->old_T0 = add( G729ABDec->old_T0, 1);
                if( sub(G729ABDec->old_T0, PIT_MAX) > 0) {
                  G729ABDec->old_T0 = PIT_MAX;
                }
              }
          }
        *T2++ = T0;

        /*-------------------------------------------------*
         * - Find the adaptive codebook vector.            *
       
		*-------------------------------------------------*/
        
        Pred_lt_31(&G729ABDec->exc[i_subfr], T0, T0_frac, L_SUBFR);

        /*-------------------------------------------------------*
         * - Decode innovative codebook.                         *
         * - Add the fixed-gain pitch contribution to code[].    *
         *-------------------------------------------------------*/

        if(bfi != 0)            /* Bad frame */
          {
            G729ABDec->seed_fer = extract_l(L_add(L_shr(L_mult(G729ABDec->seed_fer, 31821), 1), 13849L));  	
            parm[0] = G729ABDec->seed_fer & (Word16)0x1fff; /* 13 bits random */
            G729ABDec->seed_fer = extract_l(L_add(L_shr(L_mult(G729ABDec->seed_fer, 31821), 1), 13849L));  	            
            parm[1] = G729ABDec->seed_fer & (Word16)0x000f; /*  4 bits random */
          }

        Decod_ACELP(parm[1], parm[0], code);
        parm +=2;

        j = shl(G729ABDec->sharp, 1);      /* From Q14 to Q15 */
        if(sub(T0, L_SUBFR) <0 ) 
        { 
          for (i = T0; i < L_SUBFR; i++) 
          {
            code[i] = add(code[i], mult(code[i-T0], j));
          }
        }

        /*-------------------------------------------------*
         * - Decode pitch and codebook gains.              *
         *-------------------------------------------------*/

        index = *parm++;        /* index of energy VQ */

        Dec_gain(index, code, L_SUBFR, bfi, 
			&G729ABDec->gain_pitch, &G729ABDec->gain_code,
			&(G729ABDec->past_qua_en[0]));

        /*-------------------------------------------------------------*
         * - Update pitch sharpening "G729ABDec->sharp" with quantized G729ABDec->gain_pitch *
         *-------------------------------------------------------------*/

        G729ABDec->sharp = G729ABDec->gain_pitch;
        if (sub(G729ABDec->sharp, SHARPMAX) > 0) { G729ABDec->sharp = SHARPMAX;  }
        if (sub(G729ABDec->sharp, SHARPMIN) < 0) { G729ABDec->sharp = SHARPMIN;  }

        /*-------------------------------------------------------*
         * - Find the total excitation.                          *
         * - Find synthesis speech corresponding to G729ABDec->exc[].       *
         *-------------------------------------------------------*/
      
        for (i = 0; i < L_SUBFR;  i++)
          {
            /* G729ABDec->exc[i] = G729ABDec->gain_pitch*G729ABDec->exc[i] + G729ABDec->gain_code*code[i]; */
            /* G729ABDec->exc[i]  in Q0   G729ABDec->gain_pitch in Q14               */
            /* code[i] in Q13  gain_codeode in Q1              */
            
            L_temp = L_mult(G729ABDec->exc[i+i_subfr], G729ABDec->gain_pitch);
            L_temp = L_mac(L_temp, code[i], G729ABDec->gain_code);
            L_temp = L_shl(L_temp, 1);
            G729ABDec->exc[i+i_subfr] = round(L_temp);
          }
       
       

        Over_fl =0;
        Overflow_check =0;
         
			 a_test=Az;
             x_test=&G729ABDec->exc[i_subfr];
             y_test=&synth[i_subfr];

				/* Copy mem[] to yy[] */

				yy_test = (Word16 *)Scratch_Mem1;
			#if 0
				for(i_test=0; i_test<M; i_test++)
				{
				   yy_test[i_test] = G729ABDec->mem_syn[i_test];
				}
			#else
				Copy(G729ABDec->mem_syn, yy_test, M);
			#endif
                
				/* Do the filtering. */
                
				for (i_test = 0; i_test <L_SUBFR; i_test++)
				{
					s_test = L_mult(x_test[i_test], a_test[0]);
                    s3_test=0;
					for (j_test = 1; j_test <= M; j_test++)
					{   
						s1_test= s_test;

						s2_test= L_mult(a_test[j_test], yy_test[-j_test+M+i_test]);
                        s3_test+=s2_test>>1;
						 s_test = s1_test - s2_test;

						if (((s1_test ^ s2_test) & MIN_32) != 0)
							{
								if ((s_test ^ s1_test) & MIN_32)
								{
									s_test = (s1_test < 0L) ? MIN_32 : MAX_32;
									Over_fl = 1;
								}
							}

						//s = L_msu(s, a[j], yy[-j]);
					}
                    
					//if((s_test>=0x10000000))
                    if((s_test>=268435456))
					{
					 Over_fl = 1;
					 s_test=0x7fffffff;
					}
					else if(s_test< -268435456)  /*0xf0000000 */
					{
					  Over_fl = 1;
					  s_test=0x80000000;
					}
					else
					{
					 s_test= s_test << 3;
					
					}
					//s = L_shl(s, 3);
					//if(s_test>=0x7fff8000)
					if(s_test>=2147450880)
					{					 
					 Over_fl=1;
					 s_test=0x7fffffff;
					 //*yy_test++ = (Word16)((s_test+ 32768)>>16);
					 yy_test[i_test+M] = (Word16)((s_test)>>16);
					}
					else
					{
					 yy_test[i_test+M] = (Word16)((s_test+ 32768)>>16);
					}

					//*yy++ = round(s);
				}

			#if 0
				for(i_test=0; i_test<L_SUBFR; i_test++)
				{
				   y_test[i_test] = yy_test[i_test+M];
				}
			#else
				//above loop is replaced with following function
				Copy(yy_test+M, y_test, L_SUBFR);
			#endif

        if(Over_fl != 0)
          {
            /* In case of overflow in the synthesis          */
            /* -> Scale down vector G729ABDec->exc[] and redo synthesis */


            	for(i=0; i<PIT_MAX+L_INTERPOL+L_FRAME; i++)
              		G729ABDec->old_exc[i] = shr(G729ABDec->old_exc[i], 2);
              

            Syn_filt1(Az, &G729ABDec->exc[i_subfr], &synth[i_subfr], L_SUBFR, G729ABDec->mem_syn, 1,Scratch_Mem1);
       
			
		}
        else
          Copy(&synth[i_subfr+L_SUBFR-M], G729ABDec->mem_syn, M);

        Az += MP1;              /* interpolated LPC parameters for next subframe */
      }
  }
  
  /*------------*
   *  For G729b
   *-----------*/
  if(bfi == 0) 
  { 
    L_temp = 0L;
    for(i=0; i<L_FRAME; i++) 
    {
      L_temp = L_mac(L_temp, G729ABDec->exc[i], G729ABDec->exc[i]);
    }
    G729ABDec->sh_sid_sav = norm_l(L_temp);
    G729ABDec->sid_sav = round(L_shl(L_temp, G729ABDec->sh_sid_sav));
    G729ABDec->sh_sid_sav = sub(16, G729ABDec->sh_sid_sav);
  }

 /*--------------------------------------------------*
  * Update signal for next frame.                    *
  * -> shift to the left by L_FRAME  G729ABDec->exc[]           *
  *--------------------------------------------------*/

  Copy_fast(&G729ABDec->old_exc[L_FRAME], &G729ABDec->old_exc[0], PIT_MAX+L_INTERPOL);

  /* for G729b */
  G729ABDec->past_ftyp = ftyp;

  return;
}

#endif // #ifdef G729AB_DECODER_ONLY




