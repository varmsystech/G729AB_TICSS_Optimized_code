/* ITU-T G.729 Software Package Release 2 (November 2006) */
/*
   ITU-T G.729A Speech Coder    ANSI-C Source Code
   Version 1.1    Last modified: September 1996

   Copyright (c) 1996,
   AT&T, France Telecom, NTT, Universite de Sherbrooke, Lucent Technologies
   All rights reserved.
*/

/* Functions Corr_xy2() and Cor_h_x()   */

#include "includes.h"

#ifdef G729AB_ENCODER_ONLY
/*---------------------------------------------------------------------------*
 * Function corr_xy2()                                                       *
 * ~~~~~~~~~~~~~~~~~~~                                                       *
 * Find the correlations between the target xn[], the filtered adaptive      *
 * codebook excitation y1[], and the filtered 1st codebook innovation y2[].  *
 *   g_coeff[2]:exp_g_coeff[2] = <y2,y2>                                     *
 *   g_coeff[3]:exp_g_coeff[3] = -2<xn,y2>                                   *
 *   g_coeff[4]:exp_g_coeff[4] = 2<y1,y2>                                    *
 *---------------------------------------------------------------------------*/

void Corr_xy2(
      Word16 xn[],           /* (i) Q0  :Target vector.                  */
      Word16 y1[],           /* (i) Q0  :Adaptive codebook.              */
      Word16 y2[],           /* (i) Q12 :Filtered innovative vector.     */
      Word16 g_coeff[],      /* (o) Q[exp]:Correlations between xn,y1,y2 */
      Word16 exp_g_coeff[],   /* (o)       :Q-format of g_coeff[]         */
      Word32 *Scratch_Mem    
)
{
      Word16   i,exp;
      Word16   exp_y2y2,exp_xny2,exp_y1y2;
      Word16   y2y2,    xny2,    y1y2;
      Word32   L_acc;
      
      Word16   * scaled_y2 		= (Word16 *)Scratch_Mem;      /* Q9 */
      Word32   *Scratch_Mem1   = (Word32* )(scaled_y2+L_SUBFR);
      /*------------------------------------------------------------------*
       * Scale down y2[] from Q12 to Q9 to avoid overflow                 *
       *------------------------------------------------------------------*/
       for(i=0; i<L_SUBFR; i++) {
         scaled_y2[i] = shr(y2[i], 3);        }

      /* Compute scalar product <y2[],y2[]> */
      L_acc = 1;                       /* Avoid case of all zeros */
      for(i=0; i<L_SUBFR; i++)
         L_acc = L_mac(L_acc, scaled_y2[i], scaled_y2[i]);    /* L_acc:Q19 */

      exp      = norm_l(L_acc);
      y2y2     = round( L_shl(L_acc, exp) );
      exp_y2y2 = add(exp, 19-16);                          /* Q[19+exp-16] */

      g_coeff[2]     = y2y2;
      exp_g_coeff[2] = exp_y2y2;

      /* Compute scalar product <xn[],y2[]> */
      L_acc = 1;                       /* Avoid case of all zeros */
      for(i=0; i<L_SUBFR; i++)
         L_acc = L_mac(L_acc, xn[i], scaled_y2[i]);           /* L_acc:Q10 */

      exp      = norm_l(L_acc);
      xny2     = round( L_shl(L_acc, exp) );
      exp_xny2 = add(exp, 10-16);                          /* Q[10+exp-16] */

      g_coeff[3]     = negate(xny2);
      exp_g_coeff[3] = sub(exp_xny2,1);                   /* -2<xn,y2> */

      /* Compute scalar product <y1[],y2[]> */
      L_acc = 1;                       /* Avoid case of all zeros */
      for(i=0; i<L_SUBFR; i++)
         L_acc = L_mac(L_acc, y1[i], scaled_y2[i]);           /* L_acc:Q10 */

      exp      = norm_l(L_acc);
      y1y2     = round( L_shl(L_acc, exp) );
      exp_y1y2 = add(exp, 10-16);                          /* Q[10+exp-16] */

      g_coeff[4]     = y1y2;
      exp_g_coeff[4] = sub(exp_y1y2,1);    ;                /* 2<y1,y2> */

      return;
}
 
/*--------------------------------------------------------------------------*
 *  Function  Cor_h_X()                                                     *
 *  ~~~~~~~~~~~~~~~~~~~                                                     *
 * Compute correlations of input response h[] with the target vector X[].   *
 *--------------------------------------------------------------------------*/

void Cor_h_X(
     Word16 h[],        	/* (i) Q12 :Impulse response of filters      */
     Word16 X[],        	/* (i)     :Target vector                    */
     Word32 D[],         	/* (o)     :Correlations between h[] and D[] */
                        	/*          Normalized to 13 bits            */
     Word32 *Scratch_Mem 	
)
{
  
 
   
   
   
  
   
   Word32 acc1,acc2,acc3,acc4;
  
   Word32 *y32=(Word32 *)Scratch_Mem; // Word32 y32[L_SUBFR];
   Word32 *Scratch_Mem1= (Word32 *)(y32+L_SUBFR);
   Word32 outer_loop,inner_loop,max;
   Word16 REG1,REG2,REG3,REG4,REG5,i,j;
   Word16 *h_pt,*X_pt; 
   Word32 *y_pt;
   max=0;
   y_pt=y32;
  

   /* first keep the result on 32 bits and find absolute maximum */
                              
  
  for(outer_loop=10;outer_loop>0;outer_loop--)
   {
     acc1=0;
	 acc2=0;
	 acc3=0;
	 acc4=0;

	 h_pt=&h[(outer_loop *4)] ;					// & h[40]
     X_pt=&X[40] ;  							// & X[40]
     
	   REG1 = *--h_pt;    //h[39]
	   REG2 = *--h_pt;    //h[38]
	   REG3 = *--h_pt;    //h[37]
	   REG4 = *--h_pt;    //h[36]

	 for(inner_loop=outer_loop-1;inner_loop >0;inner_loop--)
	 {
       
	   REG5 = *--X_pt;    //X[39]

	   acc1 = L_mac(acc1, REG5, REG1);  // acc1+=h[39]*X[39]
	   acc2 = L_mac(acc2, REG5, REG2);  // acc2+=h[38]*X[39]
	   acc3 = L_mac(acc3, REG5, REG3);  // acc3+=h[37]*X[39]
       acc4 = L_mac(acc4, REG5, REG4);  // acc4+=h[36]*X[39]
      
	   REG1 = *--h_pt;    //h[35]
	   
	   REG5 = *--X_pt;    //X[38]

	   acc1 = L_mac(acc1, REG5, REG2);  // acc1+=h[38]*X[38]
	   acc2 = L_mac(acc2, REG5, REG3);  // acc2+=h[37]*X[38]
	   acc3 = L_mac(acc3, REG5, REG4);  // acc3+=h[36]*X[38]
       acc4 = L_mac(acc4, REG5, REG1);  // acc4+=h[35]*X[38]
      
       REG2 = *--h_pt;    //h[34]
	   
	   REG5 = *--X_pt;    //X[37]

	   acc1 = L_mac(acc1, REG5, REG3);  // acc1+=h[37]*X[37]
	   acc2 = L_mac(acc2, REG5, REG4);  // acc2+=h[36]*X[37]
	   acc3 = L_mac(acc3, REG5, REG1);  // acc3+=h[35]*X[37]
       acc4 = L_mac(acc4, REG5, REG2);  // acc4+=h[34]*X[37]

	   REG3 = *--h_pt;    //h[33]
	   
	   REG5 = *--X_pt;    //X[36]

	   acc1 = L_mac(acc1, REG5, REG4);  // acc1+=h[36]*X[36]
	   acc2 = L_mac(acc2, REG5, REG1);  // acc2+=h[35]*X[36]
	   acc3 = L_mac(acc3, REG5, REG2);  // acc3+=h[34]*X[36]
       acc4 = L_mac(acc4, REG5, REG3);  // acc4+=h[33]*X[36]

	   REG4=  *--h_pt;     //h[32]

	 }

       REG5 = *--X_pt;    //X[39]

	   acc1 = L_mac(acc1, REG5, REG1);  // acc1+=h[39]*X[39]
	   acc2 = L_mac(acc2, REG5, REG2);  // acc2+=h[38]*X[39]
	   acc3 = L_mac(acc3, REG5, REG3);  // acc3+=h[37]*X[39]
       acc4 = L_mac(acc4, REG5, REG4);  // acc4+=h[36]*X[39]

	  
	   
	   REG5 = *--X_pt;    //X[38]

	   acc1 = L_mac(acc1, REG5, REG2);  // acc1+=h[38]*X[38]
	   acc2 = L_mac(acc2, REG5, REG3);  // acc2+=h[37]*X[38]
	   acc3 = L_mac(acc3, REG5, REG4);  // acc3+=h[36]*X[38]
      

	 
	   
	   REG5 = *--X_pt;    //X[36]

	   acc1 = L_mac(acc1, REG5, REG3);  // acc1+=h[36]*X[36]
	   acc2 = L_mac(acc2, REG5, REG4);  // acc2+=h[35]*X[36]

	 

   REG5 = *--X_pt;    //X[36]

	   acc1 = L_mac(acc1, REG5, REG4);  // acc1+=h[36]*X[36]

		*(y_pt++)=(acc1);
        *(y_pt++)=(acc2);
		*(y_pt++)=(acc3);
		*(y_pt++)=(acc4);
		
		acc1=L_abs(acc1);	
        if(acc1 > max) 
        {
        max = acc1;
        }
        acc2=L_abs(acc2);	
        if(acc2 > max) 
        {
        max = acc2;
        }
        acc3=L_abs(acc3);	
        if(acc3 > max) 
        {
        max = acc3;
        }
        acc4=L_abs(acc4);	
        if(acc4 > max) 
        {
        max = acc4;
        }

   }

   j = norm_l(max);
   if( sub(j,16) > 0) {
    j = 16;
   }

   j = sub(18, j);
    
   for(i=0; i<L_SUBFR; i++) {

	   D[i] = L_shr(y32[i], j) ;
   }
   
   
  
   return;

}

/*-----------------------------------------------------------------------------------------------------*/

#endif  // #ifdef G729AB_ENCODER_ONLY
