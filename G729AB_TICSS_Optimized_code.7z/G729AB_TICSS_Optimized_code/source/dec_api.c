/*
*******************************************************************************
Product     : ITU-T G.729A  8 kbit/s (G729 AB) codec.
Module      : Decoder
File        : dec_api.c
Description : API function implementation
*/
#define NULL 0
#include "codec_api.h"
#include "common.h"

#include "typedef.h"
#include "decoder.h"
#include "common_dec.h"

#ifdef G729AB_DECODER_ONLY

Int32 G729ABDEC_CreateDecoder(void** g729abdecHandle)
{
	if(g729abdecHandle == NULL)
	{
		return INVALID_ARGS;
	}

	*g729abdecHandle = NULL;

	return CreateG729ABDecoder((SpeechDecoder **)g729abdecHandle);
}



Int32 G729ABDEC_DecodeFrame (void* g729abdecHandle, Int16* srcBuf, Int32 srcLen, 
							 Int16 *dstBuf, Int32 *outSize)
{

	SpeechDecoder * lG729ABDecoder = (SpeechDecoder *) g729abdecHandle;

	if(g729abdecHandle == NULL || srcBuf == NULL || dstBuf == NULL
		|| outSize == NULL )
	{
		return INVALID_ARGS;
	}

	return lG729ABDecoder->DecodeFrame(lG729ABDecoder,
										srcBuf,srcLen,dstBuf,outSize); 
}



Int32 G729ABDEC_ResetDecoder (void* g729abdecHandle)
{
	SpeechDecoder *lG729ABDecoder = (SpeechDecoder *) g729abdecHandle;

	if((g729abdecHandle == NULL) /*|| (ParamIn == NULL)*/)
	{
		return INVALID_ARGS;
	}

	return lG729ABDecoder->Reset(lG729ABDecoder);
}


Int32 G729ABDEC_DeleteDecoder (void* g729abdecHandle)
{
	SpeechDecoder *lG729ABDecoder = (SpeechDecoder *) g729abdecHandle;

	if(g729abdecHandle == NULL)
	{
		return INVALID_ARGS;
	}
	lG729ABDecoder->Delete(lG729ABDecoder);
	return SUCCESS;
}

Int32 G729ABDEC_SetDecoderParams(void* g729abdecHandle,
									 G729ABDecoderParam *DecParams)
{
	SpeechDecoder *lG729ABDecoder = (SpeechDecoder *) g729abdecHandle;

	if((g729abdecHandle == NULL) || (DecParams == NULL))
	{
		return INVALID_ARGS;
	}

	((tG729ABDecoder*)lG729ABDecoder)->DecStaticStruct->bad_lsf = 
		DecParams->bad_frame_indicator;

	return SUCCESS;
}
#endif // #ifdef G729AB_DECODER_ONLY
