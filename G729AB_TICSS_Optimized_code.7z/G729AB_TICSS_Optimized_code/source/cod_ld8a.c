/* ITU-T G.729 Software Package Release 2 (November 2006) */
/*
   ITU-T G.729A Speech Coder with Annex B    ANSI-C Source Code
   Version 1.3    Last modified: August 1997

   Copyright (c) 1996,
   AT&T, France Telecom, NTT, Universite de Sherbrooke, Lucent Technologies,
   Rockwell International
   All rights reserved.
*/

/*-----------------------------------------------------------------*
 *   Functions Coder_ld8a and Init_Coder_ld8a                      *
 *             ~~~~~~~~~~     ~~~~~~~~~~~~~~~                      *
 *                                                                 *
 *  Init_Coder_ld8a(void);                                         *
 *                                                                 *
 *   ->Initialization of variables for the coder section.          *
 *                                                                 *
 *                                                                 *
 *  Coder_ld8a(Word16 ana[]);                                      *
 *                                                                 *
 *   ->Main coder function.                                        *
 *                                                                 *
 *                                                                 *
 *  Input:                                                         *
 *                                                                 *
 *    80 speech data should have beee copy to vector new_speech[]. *
 *    This vector is global and is declared in this function.      *
 *                                                                 *
 *  Ouputs:                                                        *
 *                                                                 *
 *    ana[]      ->analysis parameters.                            *
 *                                                                 *
 *-----------------------------------------------------------------*/
#include "includes.h"

/*-----------------------------------------------------------*
 *    Coder constant parameters (defined in "ld8a.h")        *
 *-----------------------------------------------------------*
 *   L_WINDOW    : LPC analysis window size.                 *
 *   L_NEXT      : Samples of next frame needed for autocor. *
 *   L_FRAME     : Frame size.                               *
 *   L_SUBFR     : Sub-frame size.                           *
 *   M           : LPC order.                                *
 *   MP1         : LPC order+1                               *
 *   L_TOTAL     : Total size of speech buffer.              *
 *   PIT_MIN     : Minimum pitch lag.                        *
 *   PIT_MAX     : Maximum pitch lag.                        *
 *   L_INTERPOL  : Length of filter for interpolation        *
 *-----------------------------------------------------------*/

  

/*-----------------------------------------------------------------*
 *   Function  Init_Coder_ld8a                                     *
 *            ~~~~~~~~~~~~~~~                                      *
 *                                                                 *
 *  Init_Coder_ld8a(void);                                         *
 *                                                                 *
 *   ->Initialization of variables for the coder section.          *
 *       - initialize pointers to speech buffer                    *
 *       - initialize static  pointers                             *
 *       - set static vectors to zero                              *
 *                                                                 *
 *-----------------------------------------------------------------*/
 

#ifdef G729AB_ENCODER_ONLY
void Init_Coder_ld8a(G729ABEncoderStaticStruct *G729ABEnc)
{

  /*----------------------------------------------------------------------*
  *      Initialize pointers to speech vector.                            *
  *                                                                       *
  *                                                                       *
  *   |--------------------|-------------|-------------|------------|     *
  *     previous speech           sf1           sf2         L_NEXT        *
  *                                                                       *
  *   <----------------  Total speech vector (L_TOTAL)   ----------->     *
  *   <----------------  LPC analysis window (L_WINDOW)  ----------->     *
  *   |                   <-- present frame (L_FRAME) -->                 *
  * old_speech            |              <-- new speech (L_FRAME) -->     *
  * p_window              |              |                                *
  *                     speech           |                                *
  *                             new_speech                                *
  *-----------------------------------------------------------------------*/
  G729ABEnc->frame = 0;	
  G729ABEnc->vad_enable = 0;
  G729ABEnc->old_speech = (Int16 *)G729ABEnc->old_speech_buffer;
  G729ABEnc->new_speech = G729ABEnc->old_speech + L_TOTAL - L_FRAME;         /* New speech     */
  G729ABEnc->speech     = G729ABEnc->new_speech - L_NEXT;                    /* Present frame  */
  G729ABEnc->p_window   = G729ABEnc->old_speech + L_TOTAL - L_WINDOW;        /* For LPC window */

  /* Initialize static pointers */
  G729ABEnc->old_exc= (Int16 *)G729ABEnc->old_exc_buffer;
  G729ABEnc->old_wsp= (Int16 *)G729ABEnc->old_wsp_buffer;
  G729ABEnc->wsp    = G729ABEnc->old_wsp + PIT_MAX;                       
  G729ABEnc->exc    = G729ABEnc->old_exc + PIT_MAX + L_INTERPOL;          
  
  Set_zero(G729ABEnc->old_A, M+1);  
  G729ABEnc->old_A[0]= 4096;
  G729ABEnc->old_rc[0]=0;
  G729ABEnc->old_rc[0]=1;
  G729ABEnc->mem_w0   =(Int16 *) G729ABEnc->memmory_buffer;
  G729ABEnc->mem_w    =(Int16 *)(G729ABEnc->memmory_buffer + (M/2));
  G729ABEnc->mem_zero =(Int16 *)(G729ABEnc->memmory_buffer + (M));
  /* Static vectors to zero */

  Set_zero(G729ABEnc->old_speech, L_TOTAL);
  Set_zero(G729ABEnc->old_exc, PIT_MAX+L_INTERPOL);
  Set_zero(G729ABEnc->old_wsp, PIT_MAX);                 
  Set_zero(G729ABEnc->mem_w,   M);
  Set_zero(G729ABEnc->mem_w0,  M);
  Set_zero(G729ABEnc->mem_zero, M);
  G729ABEnc->sharp = SHARPMIN;
 
  Copy((Int16*)lspoldinit,G729ABEnc->lsp_old, M);

  /* Initialize lsp_old_q[] */

  Copy(G729ABEnc->lsp_old,G729ABEnc->lsp_old_q, M);
  Lsp_encw_reset(G729ABEnc->freq_prev);
  Init_exc_err(G729ABEnc->L_exc_err);

  /* For G.729B */
  /* Initialize VAD/DTX parameters */
  G729ABEnc->pastVad = 1;
  G729ABEnc->ppastVad = 1;
  G729ABEnc->seed = INIT_SEED;
  vad_init(&(G729ABEnc->VADStruct));
  Init_lsfq_noise();

  G729ABEnc->past_qua_en[0] = -14336;
  G729ABEnc->past_qua_en[1] = -14336;
  G729ABEnc->past_qua_en[2] = -14336;
  G729ABEnc->past_qua_en[3] = -14336;

  return;
}

/*-----------------------------------------------------------------*
 *   Functions Coder_ld8a                                          *
 *            ~~~~~~~~~~                                           *
 *  Coder_ld8a(Word16 ana[]);                                      *
 *                                                                 *
 *   ->Main coder function.                                        *
 *                                                                 *
 *                                                                 *
 *  Input:                                                         *
 *                                                                 *
 *    80 speech data should have beee copy to vector new_speech[]. *
 *    This vector is global and is declared in this function.      *
 *                                                                 *
 *  Ouputs:                                                        *
 *                                                                 *
 *    ana[]      ->analysis parameters.                            *
 *                                                                 *
 *-----------------------------------------------------------------*/

void Coder_ld8a(
	 G729ABEncoderStaticStruct *G729ABEnc,
	 Word16 *New_Speech,
     Word16 ana[],       /* output  : Analysis parameters */
     Word16 frame       /* input   : frame counter       */
)
{

  


     Word16 *Aq, *Ap;              /* Pointer on Aq_t and Ap_t             */
  
  /* Scalars */

    Word16 i, j, k, i_subfr;
    Word16 T_op, T0, T0_min, T0_max, T0_frac;
    Word16 gain_pit, gain_code, index;
    Word16 temp, taming;
    Word32 L_temp;

	
	
 	Word32 *Scratch_Mem =(G729ABEnc->stack_array);
    /* LPC analysis */
	
	
    Word16 *Aq_t= (Word16 *)(Scratch_Mem);          	// Word16 Aq_t[(MP1)*2];                        
	Word16 *Ap_t= (Word16 *)(Aq_t+(MP1*2));            	// Word16 Ap_t[(MP1)*2];                    
    /* Other vectors */ 
	   
	Word16 *h1=  (Word16 *)(Ap_t+ (MP1*2));             	// Word16  h1[L_SUBFR];                           
	Word16 *xn=  (Word16 *)(h1+L_SUBFR); 	         	// Word16  xn[L_SUBFR];			            
	Word16 *xn2= (Word16 *)(xn+L_SUBFR);             	// Word16  xn2[L_SUBFR];                               
	Word16 *code= (Word16 *)(xn2+L_SUBFR);           	// Word16  code[L_SUBFR];                           
	Word16 *y1 = (Word16 *)(code+L_SUBFR);           	// Word16  y1[L_SUBFR];                             
	Word16 *y2 = (Word16 *)(y1+L_SUBFR);             	// Word16  y2[L_SUBFR];                        
	Word16 *g_coeff =(Word16 *)(y2+L_SUBFR);         	// Word16  g_coeff[4];                          
	Word16 *g_coeff_cs= (Word16 *)(g_coeff+4);       	// Word16  g_coeff_cs[5];               
	Word16 *exp_g_coeff_cs = (Word16 *)(g_coeff_cs+6); 	// Word16 exp_g_coeff_cs[5];    
    Scratch_Mem= (Word32 *)(exp_g_coeff_cs+6);         


  Copy_fast_4(New_Speech,G729ABEnc->new_speech,L_FRAME);

  

/*------------------------------------------------------------------------*
 *  - Perform LPC analysis:                                               *
 *       * autocorrelation + lag windowing                                *
 *       * Levinson-durbin algorithm to find a[]                          *
 *       * convert a[] to lsp[]                                           *
 *       * quantize and code the LSPs                                     *
 *       * find the interpolated LSPs and convert to a[] for the 2        *
 *         subframes (both quantized and unquantized)                     *
 *------------------------------------------------------------------------*/
  {
     /* For G.729B */   
	Word16 exp_R0, Vad;

    Word32 i;		

	//Word16 *lsp_new,*lsp_new_q,*lsf_new,*r_h,*r_l,*rc,*rh_nbe;
    //Word32 *r_32;
	Word16 (*lsfq_mem)[M];
	
	Word16 *lsp_new  	=   (Word16 *)(Scratch_Mem);		// Word16 lsp_new[M]	
	Word16 *lsp_new_q  	=   (Word16 *)(lsp_new + M) ;       // Word16 lsp_new_q[M];
	Word16 *lsf_new   	=   (Word16 *)(lsp_new_q + M);      // Word16 lsf_new[M];
	Word16 *r_h		  	=   (Word16 *)(lsf_new + M);        // Word16 r_h[NP+1] 
	Word16 *r_l			= 	(Word16 *)(r_h+NP+2);           // Word16 r_l[NP+1]  
	Word16 *rc 			=   (Word16 *)(r_l+NP+2);           // Word16 rc[M]
	Word16 *rh_nbe 		= 	(Word16 *)(rc+M);               // Word16 rh_nbe[MP1];            
	Word32 *r_32		=	(Word32 *)(rh_nbe+MP1+1);       // Word32 r_32[NP+1];
	Scratch_Mem        =   (Word32 *)(r_32+NP+1);
	lsfq_mem 			=   (Word16 (*)[M])(Scratch_Mem);
	Scratch_Mem		=   (Word32 *)(Scratch_Mem+((MA_NP*M)>>1));          
    
	

	/* LP analysis */
	/* Autocorrelations */
    
	 Autocorr(G729ABEnc->p_window, NP, r_h, r_l, &exp_R0,Scratch_Mem);     		
    
	 Copy(r_h, rh_nbe, MP1);
	 Lag_window(NP, r_h, r_l);                      /* Lag windowing    */
	
	 for(i=0;i<NP+1;i++)
     r_32[i]=L_Comp(r_h[i],r_l[i]);
 
   
    Levinson(r_32, Ap_t, rc, &temp,G729ABEnc->old_rc,G729ABEnc->old_A,Scratch_Mem);          
    /* Levinson Durbin  */
   
   
   
   
  						      
    Az_lsp(Ap_t, lsp_new, G729ABEnc->lsp_old,Scratch_Mem);               /* From A(z) to lsp */

    /* For G.729B */
    /* ------ VAD ------- */
    Lsp_lsf(lsp_new, lsf_new, M);
    vad(&(G729ABEnc->VADStruct),
		rc[1], lsf_new, r_h, r_l, exp_R0, G729ABEnc->p_window, frame, 
        G729ABEnc->pastVad, G729ABEnc->ppastVad, &Vad);
 
    Update_cng(G729ABEnc,rh_nbe, exp_R0, Vad,Scratch_Mem);
    
    /* ---------------------- */
    /* Case of Inactive frame */
    /* ---------------------- */

    if ((Vad == 0) && (G729ABEnc->vad_enable == 1)){

  
     
	  Get_freq_prev(G729ABEnc->freq_prev,lsfq_mem);
	  Cod_cng(G729ABEnc,G729ABEnc->exc, G729ABEnc->pastVad, G729ABEnc->lsp_old_q, Aq_t, ana, lsfq_mem, &G729ABEnc->seed,Scratch_Mem);
    
	  Update_freq_prev(G729ABEnc->freq_prev,lsfq_mem);
    
	  G729ABEnc->ppastVad = G729ABEnc->pastVad;
      G729ABEnc->pastVad = Vad;

      /* Update wsp, mem_w and mem_w0 */
      Aq = Aq_t;
      for(i_subfr=0; i_subfr < L_FRAME; i_subfr += L_SUBFR) {
        
        /* Residual signal in xn */
        Residu(Aq, &G729ABEnc->speech[i_subfr], xn, L_SUBFR);
     
		Weight_Az1(Aq, GAMMA1, M, Ap_t);
       
        /* Compute wsp and mem_w */
        Ap = Ap_t + MP1;
        Ap[0] = 4096;
        for(i=1; i<=M; i++)    /* Ap[i] = Ap_t[i] - 0.7 * Ap_t[i-1]; */
          Ap[i] = sub(Ap_t[i], mult(Ap_t[i-1], 22938));

        Syn_filt(Ap, xn, &G729ABEnc->wsp[i_subfr], L_SUBFR, G729ABEnc->mem_w, 1,Scratch_Mem);
        
        
        /* Compute mem_w0 */
        for(i=0; i<L_SUBFR; i++) 
        {
          xn[i] = sub(xn[i], G729ABEnc->exc[i_subfr+i]);  /* residu[] - exc[] */
        }
        

        Syn_filt(Ap_t, xn, xn, L_SUBFR, G729ABEnc->mem_w0, 1,Scratch_Mem);
                
        Aq += MP1;
      }
      
      
      G729ABEnc->sharp = SHARPMIN;
      
      /* Update memories for next frames */
	
      Copy_fast(&G729ABEnc->old_speech[L_FRAME], 
						   &G729ABEnc->old_speech[0], L_TOTAL-L_FRAME);
      Copy_fast(&G729ABEnc->old_wsp[L_FRAME], &G729ABEnc->old_wsp[0], PIT_MAX);
      Copy_fast(&G729ABEnc->old_exc[L_FRAME], &G729ABEnc->old_exc[0], PIT_MAX+L_INTERPOL);
      
      return;

    }  /* End of inactive frame case */
    


    /* -------------------- */
    /* Case of Active frame */
    /* -------------------- */
    
    /* Case of active frame */
    *ana++ = 1;
    G729ABEnc->seed = INIT_SEED;
    G729ABEnc->ppastVad = G729ABEnc->pastVad;
    G729ABEnc->pastVad = Vad;

    /* LSP quantization */

    Qua_lsp(lsp_new, lsp_new_q, ana,G729ABEnc->freq_prev,Scratch_Mem);
    ana += 2;                         /* Advance analysis parameters pointer */

    /*--------------------------------------------------------------------*
     * Find interpolated LPC parameters in all subframes                  *
     * The interpolated parameters are in array Aq_t[].                   *
     *--------------------------------------------------------------------*/

    Int_qlpc(G729ABEnc->lsp_old_q, lsp_new_q, Aq_t,Scratch_Mem);

    /* Compute A(z/gamma) */

    Weight_Az1(&Aq_t[0],   GAMMA1, M, &Ap_t[0]);
    Weight_Az1(&Aq_t[MP1], GAMMA1, M, &Ap_t[MP1]); 

    /* update the LSPs for the next frame */

    Copy(lsp_new,   G729ABEnc->lsp_old,   M);
    Copy(lsp_new_q, G729ABEnc->lsp_old_q, M);
  }

 /*----------------------------------------------------------------------*
  * - Find the weighted input speech w_sp[] for the whole speech frame   *
  * - Find the open-loop pitch delay                                     *
  *----------------------------------------------------------------------*/

  Residu(&Aq_t[0], &G729ABEnc->speech[0], &G729ABEnc->exc[0], L_SUBFR);
  Residu(&Aq_t[MP1], &G729ABEnc->speech[L_SUBFR], &G729ABEnc->exc[L_SUBFR], L_SUBFR);

  {
    Word16 Ap1[MP1];

    Ap = Ap_t;
    Ap1[0] = 4096;
    for(i=1; i<=M; i++)    /* Ap1[i] = Ap[i] - 0.7 * Ap[i-1]; */
       Ap1[i] = sub(Ap[i], mult(Ap[i-1], 22938));

    Syn_filt(Ap1, &G729ABEnc->exc[0], &G729ABEnc->wsp[0], L_SUBFR, G729ABEnc->mem_w, 1,Scratch_Mem);

    Ap += MP1;
    for(i=1; i<=M; i++)    /* Ap1[i] = Ap[i] - 0.7 * Ap[i-1]; */
       Ap1[i] = sub(Ap[i], mult(Ap[i-1], 22938));

    Syn_filt(Ap1, &G729ABEnc->exc[L_SUBFR], &G729ABEnc->wsp[L_SUBFR], L_SUBFR, G729ABEnc->mem_w, 1,Scratch_Mem);
  }

  /* Find open loop pitch lag */
  

  T_op = Pitch_ol_fast(G729ABEnc->wsp, PIT_MAX, L_FRAME,Scratch_Mem);

  /* Range for closed loop pitch search in 1st subframe */
 

  T0_min = sub(T_op, 3);
  if (sub(T0_min,PIT_MIN)<0) {
    T0_min = PIT_MIN;
  }

  T0_max = add(T0_min, 6);
  if (sub(T0_max ,PIT_MAX)>0)
  {
     T0_max = PIT_MAX;
     T0_min = sub(T0_max, 6);
  }
 /*------------------------------------------------------------------------*
  *          Loop for every subframe in the analysis frame                 *
  *------------------------------------------------------------------------*
  *  To find the pitch and innovation parameters. The subframe size is     *
  *  L_SUBFR and the loop is repeated 2 times.                             *
  *     - find the weighted LPC coefficients                               *
  *     - find the LPC residual signal res[]                               *
  *     - compute the target signal for pitch search                       *
  *     - compute impulse response of weighted synthesis filter (h1[])     *
  *     - find the closed-loop pitch parameters                            *
  *     - encode the pitch delay                                           *
  *     - find target vector for codebook search                           *
  *     - codebook search                                                  *
  *     - VQ of pitch and codebook gains                                   *
  *     - update states of weighting filter                                *
  *------------------------------------------------------------------------*/

  Aq = Aq_t;    /* pointer to interpolated quantized LPC parameters */
  Ap = Ap_t;    /* pointer to weighted LPC coefficients             */
  
   
  for (i_subfr = 0;  i_subfr < L_FRAME; i_subfr += L_SUBFR)
  {

    /*---------------------------------------------------------------*
     * Compute impulse response, h1[], of weighted synthesis filter  *
     *---------------------------------------------------------------*/

    h1[0] = 4096;
    Set_zero(&h1[1], L_SUBFR-1);

    Syn_filt(Ap, h1, h1, L_SUBFR, &h1[2], 0,Scratch_Mem);

   /*----------------------------------------------------------------------*
    *  Find the target vector for pitch search:                            *
    *----------------------------------------------------------------------*/

    Syn_filt(Ap, &G729ABEnc->exc[i_subfr], xn, L_SUBFR, G729ABEnc->mem_w0, 0,Scratch_Mem);

    /*---------------------------------------------------------------------*
     *                 Closed-loop fractional pitch search                 *
     *---------------------------------------------------------------------*/

    T0 = Pitch_fr3_fast(&G729ABEnc->exc[i_subfr], xn, h1, L_SUBFR, T0_min, T0_max,
                    i_subfr, &T0_frac,Scratch_Mem);

    index = Enc_lag3(T0, T0_frac, &T0_min, &T0_max,PIT_MIN,PIT_MAX,i_subfr);

    *ana++ = index;

    if (i_subfr == 0) {
      *ana++ = Parity_Pitch(index);
    }

   /*-----------------------------------------------------------------*
    *   - find filtered pitch exc                                     *
    *   - compute pitch gain and limit between 0 and 1.2              *
    *   - update target vector for codebook search                    *
    *-----------------------------------------------------------------*/

    Syn_filt(Ap, &G729ABEnc->exc[i_subfr], y1, L_SUBFR, G729ABEnc->mem_zero, 0,Scratch_Mem);

    gain_pit = G_pitch(xn, y1, g_coeff, L_SUBFR,Scratch_Mem);

    /* clip pitch gain if taming is necessary */

    taming = test_err(G729ABEnc->L_exc_err,T0, T0_frac);

    if( taming == 1){
      if (sub(gain_pit, GPCLIP) > 0) {
        gain_pit = GPCLIP;
      }
    }

    /* xn2[i]   = xn[i] - y1[i] * gain_pit  */

   
    
   
   

    for (i = 0; i < L_SUBFR; i++)
    {
      L_temp = L_mult(y1[i], gain_pit);
      L_temp = L_shl(L_temp, 1);               /* gain_pit in Q14 */
      xn2[i] = sub(xn[i], extract_h(L_temp));
    }
   /*-----------------------------------------------------*
    * - Innovative codebook search.                       *
    *-----------------------------------------------------*/

    index = ACELP_Code_A(xn2, h1, T0, G729ABEnc->sharp, code, y2, &i,Scratch_Mem);
   
    *ana++ = index;        /* Positions index */
    *ana++ = i;            /* Signs index     */


   /*-----------------------------------------------------*
    * - Quantization of gains.                            *
    *-----------------------------------------------------*/

    g_coeff_cs[0]     = g_coeff[0];            /* <y1,y1> */
    exp_g_coeff_cs[0] = negate(g_coeff[1]);    /* Q-Format:XXX -> JPN */
    g_coeff_cs[1]     = negate(g_coeff[2]);    /* (xn,y1) -> -2<xn,y1> */
    exp_g_coeff_cs[1] = negate(add(g_coeff[3], 1)); /* Q-Format:XXX -> JPN */

    	

      							
    Corr_xy2( xn, y1, y2, g_coeff_cs, exp_g_coeff_cs,Scratch_Mem );  /* Q0 Q0 Q12 ^Qx ^Q0 */
                         /* g_coeff_cs[3]:exp_g_coeff_cs[3] = <y2,y2>   */
                         /* g_coeff_cs[4]:exp_g_coeff_cs[4] = -2<xn,y2> */
                         /* g_coeff_cs[5]:exp_g_coeff_cs[5] = 2<y1,y2>  */

    *ana++ = Qua_gain(code, g_coeff_cs, exp_g_coeff_cs,
                         L_SUBFR, &gain_pit, &gain_code, taming,
						 G729ABEnc->past_qua_en,Scratch_Mem);


   /*------------------------------------------------------------*
    * - Update pitch sharpening "sharp" with quantized gain_pit  *
    *------------------------------------------------------------*/

    G729ABEnc->sharp = gain_pit;
    if (sub(G729ABEnc->sharp, SHARPMAX) > 0) { G729ABEnc->sharp = SHARPMAX;         }
    if (sub(G729ABEnc->sharp, SHARPMIN) < 0) { G729ABEnc->sharp = SHARPMIN;         }

   /*------------------------------------------------------*
    * - Find the total excitation                          *
    * - update filters memories for finding the target     *
    *   vector in the next subframe                        *
    *------------------------------------------------------*/
   
    for (i = 0; i < L_SUBFR;  i++)
    {
      /* exc[i] = gain_pit*exc[i] + gain_code*code[i]; */
      /* exc[i]  in Q0   gain_pit in Q14               */
      /* code[i] in Q13  gain_cod in Q1                */

      L_temp = L_mult(G729ABEnc->exc[i+i_subfr], gain_pit);
      L_temp = L_mac(L_temp, code[i], gain_code);
      L_temp = L_shl(L_temp, 1);
      G729ABEnc->exc[i+i_subfr] = round(L_temp);
    }
   
   
   
    update_exc_err(G729ABEnc->L_exc_err,gain_pit, T0);

    for (i = L_SUBFR-M, j = 0; i < L_SUBFR; i++, j++)
    {
      temp       = extract_h(L_shl( L_mult(y1[i], gain_pit),  1) );
      k          = extract_h(L_shl( L_mult(y2[i], gain_code), 2) );
      G729ABEnc->mem_w0[j]  = sub(xn[i], add(temp, k));
    }

    Aq += MP1;           /* interpolated LPC parameters for next subframe */
    Ap += MP1;

  }

 /*--------------------------------------------------*
  * Update signal for next frame.                    *
  * -> shift to the left by L_FRAME:                 *
  *     speech[], wsp[] and  exc[]                   *
  *--------------------------------------------------*/

  Copy(&G729ABEnc->old_speech[L_FRAME],
					   &G729ABEnc->old_speech[0], L_TOTAL-L_FRAME);
  Copy(&G729ABEnc->old_wsp[L_FRAME], &G729ABEnc->old_wsp[0], PIT_MAX);
  Copy(&G729ABEnc->old_exc[L_FRAME], &G729ABEnc->old_exc[0], PIT_MAX+L_INTERPOL);

  return;
}
#endif  //#ifdef G729AB_ENCODER_ONLY
