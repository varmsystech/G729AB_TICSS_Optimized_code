/*
*******************************************************************************
Product     : ITU-T G.729A  8 kbit/s (G729 AB) codec.
Module      : Decoder
File        : decoder.h
Description : declaration of encoder object
*/

#ifndef INCLUDE_G729AB_DECODER
#define INCLUDE_G729AB_DECODER

#include "common_dec.h"
#include "includes.h"

#ifdef  G729AB_DECODER_ONLY

typedef struct G729ABDecoder tG729ABDecoder;

struct G729ABDecoder
{
	/* Function pointer to encode a frame */
	Int32  (*DecodeFrame) (SpeechDecoder *g729abcontext,
							Int16* srcBuf, 
							Int32  scrLen, 
							Int16* dstBuf,
							Int32* dstLen);

    /* Function Ptr to reset the encoder */
	Int32 (*Reset) (SpeechDecoder *g729abcontext);
	/* Function ptr to get a specified parameter value */
    void (*Delete) (SpeechDecoder *g729abcontext);

	G729ABDecoderStaticStruct *DecStaticStruct;
};

Int32 CreateG729ABDecoder(SpeechDecoder **g729abcontext);

#endif //#ifdef  G729AB_DECODER_ONLY
#endif

