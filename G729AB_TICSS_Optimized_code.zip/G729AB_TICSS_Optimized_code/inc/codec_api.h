/*
*******************************************************************************
Product     : ITU-T G.729A  8 kbit/s (G729 AB) codec.
Module      : Encoder and Decoder
File        : codec_api.h
Description : API function implementation 

*/
/*
 *	 G729 AB Codec can be used to encode and decode the speech signals as 
 *   specified by the ITU-T recommendations. The encode bit-rate is 8kbps. The G72AB
 *   also has a silence compression scheme to reduce the transmission rate during 
 *	 silence periods of speech. 
 *
 */
#ifndef CODEC_API
#define CODEC_API

#include "common.h"
#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

#define  L_FRAME      80      /* Frame size.                                */
#define  SERIAL_SIZE  (80+2)  /* bfi+ number of speech bits                 */
#define  PRM_SIZE     11      /* Size of vector of analysis parameters.     */

typedef struct G729ABEncoderParam
{
    Int16 vad_enable;
}G729ABEncoderParam;
typedef struct G729ABDecoderParam
{
    Int16 bad_frame_indicator;
}G729ABDecoderParam;


Int32 G729ABENC_CreateEncoder(void** g729abencHandle);


Int32 G729ABENC_ResetEncoder (void* g729abencHandle);


Int32 G729ABENC_SetEncoderParams(void* g729abencHandle,
									 G729ABEncoderParam *EncParams);


Int32 G729ABENC_EncodeFrame (void* g729abencHandle,
								 Int16* srcBuf,
								 Int32 srcLen, 
								 Int16 *dstBuf,
								 Int32 *DstLen);


Int32 G729ABENC_DeleteEncoder (void* g729abencHandle);


Int32 G729ABDEC_CreateDecoder(void** g729abdecHandle);


Int32 G729ABDEC_ResetDecoder (void* g729abdecHandle);


Int32 G729ABDEC_SetDecoderParams(void* g729abdecHandle,
									 G729ABDecoderParam *DecParams);


Int32 G729ABDEC_DecodeFrame (void* g729abdecHandle,
								 Int16* srcBuf,
								 Int32 srcLen, 
								 Int16 *dstBuf,
								 Int32 *outSize);


Int32 G729ABDEC_DeleteDecoder (void* g729abdecHandle);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif





