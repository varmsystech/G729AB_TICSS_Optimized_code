/*
*******************************************************************************
Product     :  Speech Decoder
Module      : 
File        : common_dec.h
Description : Speech decoder class definition.
*/

#ifndef COMMON_DEC
#define COMMON_DEC

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */
#ifdef G729AB_DECODER_ONLY
typedef struct SpeechDecoder SpeechDecoder;


struct SpeechDecoder
{
	Int32  (*DecodeFrame)(SpeechDecoder *g729abcontext, Int16* src, Int32 SrcLen, 
								Int16 *dstBuf, Int32* dstLen);  	
	/* Function ptr to get a specified parameter value */    
    Int32 (*Reset) (SpeechDecoder *g729abcontext);
	Int32 (*Delete) (SpeechDecoder *g729abcontext);
};
#ifdef __cplusplus
}
#endif
#endif // #ifdef G729AB_DECODER_ONLY 
#endif







