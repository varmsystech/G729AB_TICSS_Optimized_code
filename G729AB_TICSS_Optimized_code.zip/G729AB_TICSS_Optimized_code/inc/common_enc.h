/*
*******************************************************************************
Product     : Common Module
Module      : Basic Speech Encoder Object
File        : common_enc.h
Description : Declaration of speech encoder object.
*/

#ifndef COMMON_ENC
#define COMMON_ENC

#ifdef G729AB_ENCODER_ONLY

typedef struct GSpeechEncoder SpeechEncoder;


struct GSpeechEncoder
{
	Int32  (*EncodeFrame) (SpeechEncoder *g729abcontext,
							Int16* srcBuf, 
							Int32  scrLen, 
							Int16* dstBuf,
							Int32* dstLen);

    /* Function Ptr to reset the encoder */
	Int32 (*Reset) (SpeechEncoder *g729abcontext);
	/* Function ptr to get a specified parameter value */
    Int32 (*Delete) (SpeechEncoder *g729abcontext);
	
};
#endif // #ifdef G729AB_ENCODER_ONLY
#endif






