/* ITU-T G.729 Software Package Release 2 (November 2006) */
/*
   ITU-T G.729A Speech Coder with Annex B    ANSI-C Source Code
   Version 1.5    Last modified: October 2006

   Copyright (c) 1996,
   AT&T, France Telecom, NTT, Universite de Sherbrooke, Lucent Technologies,
   Rockwell International
   All rights reserved.
*/

#include <stdio.h>               /* for file operations */
#include <stdlib.h>
#include <string.h>
#include "includes.h"



#ifdef G729AB_DECODER_ONLY
/*
   This variable should be always set to zero unless transmission errors
   in LSP indices are detected.
   This variable is useful if the channel coding designer decides to
   perform error checking on these important parameters. If an error is
   detected on the  LSP indices, the corresponding flag is
   set to 1 signalling to the decoder to perform parameter substitution.
   (The flags should be set back to 0 for correct transmission).
*/



/*
*******************************************************************************
Name            : G.729ABDecodeFrame 
Description     : Decode a frame function.
Parameter       : Decoder object pointer to g.729AB decoder object.
Return Value    : SUCCESS / FAILURE
*******************************************************************************
*/
static Int32  sG729ABDecodeFrame (SpeechDecoder *g729abcontext,
								  Int16* src, 
								  Int32 srcLen, 
								  Int16* dst,
								  Int32* dstLen)
{

	tG729ABDecoder *lG729ABDec = (tG729ABDecoder*)g729abcontext;
	
	
	Int16  Vad;	
    Int16  i;
	
	
    //Int16  Az_dec[MP1*2];                /* Decoded Az for post-filter  */
	//Int16  parm[PRM_SIZE+2];             /* Synthesis parameters        */
    //Int16  T2[2];                        /* Pitch lag for 2 subframes   */
    
    Word32 *Scratch_Mem =  lG729ABDec->DecStaticStruct->stack_array;
	
	Int16 *Az_dec = (Int16*) Scratch_Mem;
    Int16 *parm   = (Int16*) (Az_dec + MP1 *2);         // Az_dec[MP1*2]; MP1 *2 = 22
    Int16 *T2     = (Int16*)  (parm+(PRM_SIZE+2+1));    // parm[PRM_SIZE+2]; is 13 make it even 14
    Word32    *Scratch_Mem1=(Word32 *)  (T2+2);                    // Int16  T2[2];
	
	//Int16  Az_dec[MP1*2];                /* Decoded Az for post-filter  */
	//Int16  parm[PRM_SIZE+2];             /* Synthesis parameters        */
    //Int16  T2[2];                        /* Pitch lag for 2 subframes   */

     bits2prm_ld8k(&src[1], parm);
     
    

    /* This part was modified for version V1.3 */
    /* for speech and SID frames, the hardware detects frame erasures
	 by checking if all bits are set to zero */
    /* for untransmitted frames, the hardware detects frame erasures
	 by testing serial[0] */

	parm[0] = 0;           /* No frame erasure */
	if(src[1] != 0) 
	{
	for (i=0; i < src[1]; i++)
	 if (src[i+2] == 0 ) parm[0] = 1;  /* frame erased     */
	}
	else if(src[0] != SYNC_WORD) parm[0] = 1;

	if(parm[1] == 1) 
	{
	/* check parity and put 1 in parm[5] if parity error */
	parm[5] = Check_Parity_Pitch(parm[4], parm[5]);
	}

    /*This function uses a total of 620 bytes of memory*/	
	Decod_ld8a(lG729ABDec->DecStaticStruct,parm,
								lG729ABDec->DecStaticStruct->synth, Az_dec, T2, &Vad,Scratch_Mem1);
   
   /*his function uses a total of 552 bytes of memmory*/
    Post_Filter(&(lG729ABDec->DecStaticStruct->PostFilterStruct),
								lG729ABDec->DecStaticStruct->synth, Az_dec, T2, Vad,Scratch_Mem1);        /* Post-filter */
	

	Post_Process(&(lG729ABDec->DecStaticStruct->PostProStruct),
								lG729ABDec->DecStaticStruct->synth, L_FRAME);
    
	Copy(lG729ABDec->DecStaticStruct->synth,dst,L_FRAME);
    
	*dstLen = L_FRAME;

    return SUCCESS;
}

/*
*******************************************************************************
Name            : G.729ABGetParam 
Description     : releases the resources used by the encoder object.
Parameter       : Encoder object pointer to g.729AB decoder object.
				  
Return Value    : SUCCESS/Param/UNDEFINED_FLAG
*******************************************************************************
*/
static void sG729ABDecoderDelete (SpeechDecoder *g729abcontext)
{

	tG729ABDecoder  *lDerv;
    if(g729abcontext)
    {
        lDerv = (tG729ABDecoder*) g729abcontext;

        /* Delete encoder static block */
        if(lDerv->DecStaticStruct != NULL)
            free(lDerv->DecStaticStruct);
    
	    /* free the current object */
        if(lDerv != NULL)
            free(lDerv);
    }

}

/*
*******************************************************************************
Name            : G.729ABReset 
Description     : releases the resources used by the Decoder object.
Parameter       : Decoder object pointer to g.729AB Decoder object.
				  
Return Value    : SUCCESS/Param/UNDEFINED_FLAG
*******************************************************************************
*/

Int32 sG729ABDecoderReset(SpeechDecoder *g729abcontext)
{
	tG729ABDecoder *lG729ABDec;
	
	if(g729abcontext)
	{
		lG729ABDec = (tG729ABDecoder*)g729abcontext;

		/*-----------------------------------------------------------------*
		*           Initialization of decoder                             *
		*-----------------------------------------------------------------*/	

		Init_Decod_ld8a(lG729ABDec->DecStaticStruct);
		Init_Post_Filter(&(lG729ABDec->DecStaticStruct->PostFilterStruct));
		Init_Post_Process(&(lG729ABDec->DecStaticStruct->PostProStruct));

		/* for G.729b */
		Init_Dec_cng(lG729ABDec->DecStaticStruct);

		return SUCCESS;
	}
	else
	{
		return INVALID_ARGS;
	}
	

}



/*
*******************************************************************************
Name            : CreateG729ABDecoder
Description     : Creation function for G729AB Decoder object.
Parameter       : g729abcontext - Output g.729ABDecoder object
Return Value    : SUCCESS/OUT_OF_MEMORY/FAILURE
*******************************************************************************
*/
int G729_DecMem[20000];
Int32 CreateG729ABDecoder(SpeechDecoder **g729abcontext)
{
		tG729ABDecoder *lG729ABDec = (tG729ABDecoder*)malloc(sizeof(tG729ABDecoder));

		if(lG729ABDec == NULL) 
        {
            return OUT_OF_MEMORY;
        }
		
	
    	memset(lG729ABDec,0, sizeof(tG729ABDecoder));

		lG729ABDec->DecStaticStruct = (G729ABDecoderStaticStruct*)G729_DecMem;// malloc(sizeof(G729ABDecoderStaticStruct));

		
		if(lG729ABDec->DecStaticStruct == NULL) 
        {
			free(lG729ABDec);
            return OUT_OF_MEMORY;
        }

	
		lG729ABDec->Delete = sG729ABDecoderDelete;
		lG729ABDec->DecodeFrame = sG729ABDecodeFrame;		
		lG729ABDec->Reset = sG729ABDecoderReset;
        *g729abcontext = (SpeechDecoder*) lG729ABDec;
        lG729ABDec->Reset(*g729abcontext);
	
		return SUCCESS;
}
#endif // #ifdef G729AB_DECODER_ONLY
