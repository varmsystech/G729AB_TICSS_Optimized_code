/* ITU-T G.729 Software Package Release 2 (November 2006) */
/*
   ITU-T G.729A Speech Coder with Annex B    ANSI-C Source Code
   Version 1.5    Last modified: October 2006

   Copyright (c) 1996,
   AT&T, France Telecom, NTT, Universite de Sherbrooke, Lucent Technologies,
   Rockwell International
   All rights reserved.
*/

#include <stdio.h>               /* for file operations */
#include <stdlib.h>
#include <string.h>

#include "includes.h"

#ifdef G729AB_ENCODER_ONLY
/*
*******************************************************************************
Name            : G729ABEncodeFrame 
Description     : Encode a frame function.
Parameter       : Encoder object pointer to G.729AB encoder object.
Return Value    : SUCCESS / FAILURE
*******************************************************************************
*/
static Int32  G729ABEncodeFrame (SpeechEncoder *g729abcontext,
								  Int16* src, 
								  Int32  srcLen, 
								  Int16* dst,
								  Int32* dstLen)
{

	G729ABEncoder *G729ABEnc = (G729ABEncoder*)g729abcontext;

	Int16 prm[PRM_SIZE+1];        /* Analysis parameters + frame type      */
	
	if (G729ABEnc->EncStaticStruct->frame == 32767) 
	{
		G729ABEnc->EncStaticStruct->frame = 256;
	}
    else
	{
		G729ABEnc->EncStaticStruct->frame++;
	}

	Pre_Process(&(G729ABEnc->EncStaticStruct->PreProStruct),
						        src, L_FRAME);
    Coder_ld8a(G729ABEnc->EncStaticStruct,
								src,
								prm,
								G729ABEnc->EncStaticStruct->frame);

    if(FAILURE==prm2bits_ld8k( prm, dst))
    {
      return FAILURE;
    }
    *dstLen = dst[1] +  (Int16)2;

    return SUCCESS;
}

/*
*******************************************************************************
Name            : G729ABGetParam 
Description     : releases the resources used by the encoder object.
Parameter       : Eencoder object pointer to G.729AB encoder object.
				  
Return Value    : SUCCESS/Param/UNDEFINED_FLAG
*******************************************************************************
*/
static void G729ABEncoderDelete (SpeechEncoder *g729abcontext)
{

	G729ABEncoder  *Derv;
    if(g729abcontext)
    {
        Derv = (G729ABEncoder*) g729abcontext;
	    /* free the current object */
        if(Derv != NULL)
            free(Derv);
    }

}

/*
*******************************************************************************
Name            : G.729ABReset 
Description     : releases the resources used by the encoder object.
Parameter       : Encoder object pointer to g.729AB encoder object.
				  
Return Value    : SUCCESS/Param/UNDEFINED_FLAG
*******************************************************************************
*/

Int32 G729ABEncoderReset(SpeechEncoder *g729abcontext)
{
	G729ABEncoder *G729ABEnc;

	if(g729abcontext)
	{
		G729ABEnc = (G729ABEncoder*)g729abcontext;

		//memset(lG729ABEnc,0, sizeof(G729ABEncoder));

		Init_Pre_Process(&(G729ABEnc->EncStaticStruct->PreProStruct));
		Init_Coder_ld8a(G729ABEnc->EncStaticStruct);
		
		/* for G.729B */
		Init_Cod_cng(&(G729ABEnc->EncStaticStruct->DTXStruct));
		return SUCCESS;
	}
	else
	{
		return INVALID_ARGS;
	}
	

}



/*
*******************************************************************************
Name            : CreateG729ABEncoder
Description     : Creation function for G729AB Encoder object.
Parameter       : Output g.729ABEncoder object
Return Value    : SUCCESS/OUT_OF_MEMORY/FAILURE
*******************************************************************************
*/
int G729_EncMem[20000]; 
Int32 CreateG729ABEncoder(SpeechEncoder **g729abcontext)
{
		G729ABEncoder *G729ABEnc = (G729ABEncoder*)malloc(sizeof(G729ABEncoder));

		if(G729ABEnc == NULL) 
        {
            return OUT_OF_MEMORY;
        }
		
		/* Initialize all the internal members */
    	memset(G729ABEnc,0, sizeof(G729ABEncoder));

		G729ABEnc->EncStaticStruct = (G729ABEncoderStaticStruct*)G729_EncMem;
	
		G729ABEnc->Delete = G729ABEncoderDelete;
		G729ABEnc->EncodeFrame = G729ABEncodeFrame;		
		G729ABEnc->Reset = G729ABEncoderReset;
        *g729abcontext = (SpeechEncoder*) G729ABEnc;
        G729ABEnc->Reset(*g729abcontext);
	
		return SUCCESS;
}
#endif //#ifdef G729AB_ENCODER_ONLY
