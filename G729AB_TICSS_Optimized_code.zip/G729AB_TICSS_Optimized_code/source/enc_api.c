/*
*******************************************************************************
Product     : ITU-T G.729A  8 kbit/s (G729 AB) codec.
Module      : Encoder
File        : enc_api.c
Description : API function implementation
*/

#define NULL 0

#include "common.h"
#include "typedef.h"
#include "encoder.h"
#include "common_enc.h"

#ifdef G729AB_ENCODER_ONLY
Int32 G729ABENC_CreateEncoder(void** g729abencHandle)
{
	if(g729abencHandle == NULL)
	{
		return INVALID_ARGS;
	}

	*g729abencHandle = NULL;

	return CreateG729ABEncoder((SpeechEncoder **)g729abencHandle);
}

Int32 G729ABENC_EncodeFrame (void* g729abencHandle, Int16* srcBuf, Int32 srcLen, 
							 Int16 *dstBuf, Int32 *outSize)
{

	SpeechEncoder * G729ABEncoder = (SpeechEncoder *) g729abencHandle;

	if(g729abencHandle == NULL || srcBuf == NULL || dstBuf == NULL
		|| outSize == NULL )
	{
		return INVALID_ARGS;
	}

	if(srcLen != L_FRAME)
	{
		return 0;
	}

	return G729ABEncoder->EncodeFrame(G729ABEncoder,
										srcBuf,srcLen,dstBuf,outSize); 
}

Int32 G729ABENC_ResetEncoder (void* g729abencHandle)
{
	SpeechEncoder *lG729ABEncoder = (SpeechEncoder *) g729abencHandle;

	if((g729abencHandle == NULL) /*|| (ParamIn == NULL)*/)
	{
		return INVALID_ARGS;
	}

	return lG729ABEncoder->Reset(lG729ABEncoder);
}

Int32 G729ABENC_DeleteEncoder (void* g729abencHandle)
{
	SpeechEncoder *lG729ABEncoder = (SpeechEncoder *) g729abencHandle;

	if(g729abencHandle == NULL)
	{
		return INVALID_ARGS;
	}
	lG729ABEncoder->Delete(lG729ABEncoder);
	return SUCCESS;
}

Int32 G729ABENC_SetEncoderParams(void* g729abencHandle,
									 G729ABEncoderParam *EncParams)
{
	SpeechEncoder *lG729ABEncoder = (SpeechEncoder *) g729abencHandle;

	if((g729abencHandle == NULL) || (EncParams == NULL))
	{
		return INVALID_ARGS;
	}

	((G729ABEncoder*)lG729ABEncoder)->EncStaticStruct->vad_enable = 
		EncParams->vad_enable;

	return SUCCESS;
}
#endif //#ifdef G729AB_ENCODER_ONLY


