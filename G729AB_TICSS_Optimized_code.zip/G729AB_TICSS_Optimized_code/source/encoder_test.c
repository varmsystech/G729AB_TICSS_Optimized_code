/*
*******************************************************************************
Product     : ITU-T G.729A  8 kbit/s (G729 AB) codec.
Module      : Encoder
File        : encoder_test.c
Description : This is the source file for Encoder module (main function) for
				G729 AB Codec product
*/

/* Include files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "codec_api.h"
#include "common.h"


Int32 main(int argc, char *argv[])
{
    FILE *f_speech = NULL;       /* File of speech data                   */
    FILE *f_serial = NULL;       /* File of serial bits for transmission  */
    FILE *f_serial_ref = NULL;       /* reference File of serial bits for transmission  */

	void  *lG729ABEncoder = NULL;
	
	Int16 new_speech[L_FRAME];     /* Pointer to new speech data            */
	Int16 serial[SERIAL_SIZE];    /* Output bitstream buffer               */
	Int16 serial_ref[SERIAL_SIZE];    /* referece Output bitstream buffer               */

	Int32 i,nb_words;
	Int32 noFrames;
	Int32 countFrames;
	G729ABEncoderParam EncParams;
	printf("\n");
	printf("***********    ITU G.729A 8 KBIT/S SPEECH CODER    ***********\n");
	printf("                        (WITH ANNEX B)                        \n");
	printf("\n");
	printf("------------------- Fixed point C simulation -----------------\n");
	printf("\n");
	printf("------------ Version 1.5 (Release 2, November 2006) ----------\n");
	printf("\n");

	/* Open the input file */
	if ((f_speech = fopen("..\\..\\..\\test_css\\tstseq1.bin", "rb")) == NULL) {
		printf("%s - Error opening input file \n");
		goto TheEnd;
	}
	/* Open the output file */
	if ((f_serial = fopen("..\\..\\..\\test_css\\tstseq1_vad_on_ccs.enc", "wb")) == NULL) {
		printf("%s - Error opening output file  \n");
		goto TheEnd;
	}
	if ((f_serial_ref = fopen("..\\..\\..\\test_css\\tstseq1_vad_on.enc", "rb")) == NULL) {
		printf("%s - Error opening reference file \n");
		goto TheEnd;
	}
	/* Create the encoder instance */
	if(G729ABENC_CreateEncoder(&lG729ABEncoder) == FAILURE) {
        goto TheEnd;
    }
	
	/* reset the encoder instance */
	if(G729ABENC_ResetEncoder(lG729ABEncoder) == FAILURE) {
        goto TheEnd;
    }
	
	noFrames=0;
	countFrames=0;
	EncParams.vad_enable = 1;//atoi(argv[3]); // VAD Flag
    /*-----------------------------------------------------------------*
     *            Loop for each "L_FRAME" speech data                  *
     *-----------------------------------------------------------------*/
	while (fread(new_speech, sizeof(Int16), L_FRAME, f_speech) == L_FRAME)
	{
	

		G729ABENC_SetEncoderParams(lG729ABEncoder,&EncParams);

		if(G729ABENC_EncodeFrame(lG729ABEncoder,
								   new_speech,
								   (Int32)L_FRAME, 
								   serial,
								   &nb_words)
									== FAILURE)
	
		{
			printf("FAILURE in EncoderFrame");
			goto TheEnd;
		}
	    
		fwrite(serial, sizeof(Int16), nb_words, f_serial);
		fread(serial_ref, sizeof(Int16), nb_words, f_serial_ref);
		for(i<0; i<nb_words; i++)
		{
			if(serial[i] != serial_ref[i])
				printf("Encoded Frame no serial=%d,serial_ref=%d\r",serial[i],serial_ref[i]);
				noFrames  = 0;
		}
		printf("Encoded Frame no =%d\r",countFrames);				
		countFrames++;
			
		}

TheEnd:
	if(f_speech) fclose(f_speech);
	if(f_serial) fclose(f_serial);
	if(f_serial_ref) fclose(f_serial_ref);
	
	if(lG729ABEncoder)  G729ABENC_DeleteEncoder(lG729ABEncoder);

return(0);
	
}



