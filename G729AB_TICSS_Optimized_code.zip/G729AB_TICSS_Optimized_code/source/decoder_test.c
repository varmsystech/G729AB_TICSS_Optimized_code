/*
*******************************************************************************
Product     : ITU-T G.729A  8 kbit/s (G729 AB) codec.
Module      : decoder
File        : decoder_test.c
Description : This is the source file forDecoder module (main function) for
				G729 AB Codec product
*/

/* Include files */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "codec_api.h"
#include "common.h"

/*-----------------------------------------------------------------*
 *            Main decoder routine                                 *
 *-----------------------------------------------------------------*/

Int32 main(int argc, char *argv[])
{
 
  Int32  count_frame;
  FILE   *f_syn, *f_serial,*f_syn_ref;
  void  *lG729ABDecoder = NULL;
  Int32  outlen = 0,linlen = PRM_SIZE;
  Int16  serial[SERIAL_SIZE];          /* Serial stream               */
  Int16  dst[L_FRAME];
  Int16  dst_ref[L_FRAME];
  Int32  i = 0,j =0;
  G729ABDecoderParam DecParams;
   

  printf("\n");
  printf("************  ITU G.729A 8.0 KBIT/S SPEECH DECODER  ************\n");
  printf("                       (WITH ANNEX B)                           \n");
  printf("\n");
  printf("------------------ Fixed point C simulation --------------------\n");
  printf("\n");
  printf("------------- Version 1.5 (Release 2, November 2006) ------------\n");
  printf("\n");

	/* Open the input file */
  if ((f_serial = fopen("..\\..\\..\\test_css\\tstseq1_vad_on.enc", "rb")) == NULL) {
	  printf("%s - Error opening input file \n");
		goto TheEnd;
	}
	/* Open the output file */
  if ((f_syn = fopen("..\\..\\..\\test_css\\tstseq1_vad_on_ccs.dec", "wb")) == NULL) {
		printf("%s - Error opening output file  \n");
		goto TheEnd;
	}
  if ((f_syn_ref = fopen("..\\..\\..\\test_css\\tstseq1_vad_on.dec", "rb")) == NULL) {
		printf("%s - Error opening reference file \n");
		goto TheEnd;
	}
		/* Create the encoder instance */
		if(G729ABDEC_CreateDecoder(&lG729ABDecoder) == FAILURE) {
        	goto TheEnd;
    	}

	/* reset the encoder instance */
		if(G729ABDEC_ResetDecoder(lG729ABDecoder) == FAILURE) {
        	goto TheEnd;
    	}
    
   
/*-----------------------------------------------------------------*
 *            Loop for each "L_FRAME" speech data                  *
 *-----------------------------------------------------------------*/

		count_frame = 0L;
  		while(f_serial)
  		{

			if(fread(serial, sizeof(short), 2, f_serial) != 2)
			{
				goto TheEnd;
			}

    		if(fread(&serial[2], sizeof(short), (size_t)serial[1], f_serial)
     		!= (size_t)serial[1])
			{
				goto TheEnd;
			}
	
   			DecParams.bad_frame_indicator = 0;

			G729ABDEC_SetDecoderParams(lG729ABDecoder,&DecParams);

    		if(G729ABDEC_DecodeFrame(lG729ABDecoder,
									   serial,
									   linlen, 
									   dst,
									   &outlen)
										== FAILURE)

			{
				printf("FAILURE in DecoderFrame");
				goto TheEnd;
			}  
	    
    		fwrite(dst, sizeof(short), outlen, f_syn);
    		fread(dst_ref, sizeof(Int16), outlen, f_syn_ref);
    		for(i<0; i<outlen; i++)
    		{
    			if(dst[i] != dst_ref[i])
    				printf("Decoded Frame no dst=%d,dst_ref=%d\r",dst[i],dst_ref[i]);
    		}
    		printf("Decoded Frame No = %d\r", count_frame);
    		count_frame++;
  		}

  TheEnd:
   
		if(f_serial) fclose(f_serial);
		if(f_syn) fclose(f_syn);
		if(f_syn_ref) fclose(f_syn_ref);
		if(lG729ABDecoder)  G729ABDEC_DeleteDecoder(lG729ABDecoder);

	return(0);
}
