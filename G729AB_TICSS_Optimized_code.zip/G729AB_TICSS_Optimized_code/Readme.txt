1. Fixed-point ANSI C code of G.729A with ANNEX B (Reference /* ITU-T G.729 Software Package Release 2 (November 2006) */)
   Date of Release G.729AB fixed point code - 12 Nov, 2019 by VARMSYSTECH

2. This G.729AB package comprises of following 4 folders

   a. inc         - Header files
   b. msvc:       - Two Microsoft Visual Studio C Project files for G.279AB Encoder and G.729AB Decoder
   c. source:     - C source files
   d. testvector: - Encoder and Decoder executable files generated using MSVC project.
                    Batch file 
				    4 Speech Input steams 

3. Once the MSVC project are launch for Encoder and Decoder following commard arguments need to add 
   For Encoder:- tstseq1.bin tstseq1_vad_on.enc 1 [ Input file ,Outpout file, VADFLAG-ON/OFF)
   For Decoder:- tstseq1_vad_on.enc tstseq1_vad_on.dec [Input file ,Outpout file )

4a. 
   Example to run encoder with VAD enable
   G729AB_Encoder.exe tstseq1.bin tstseq1_vad_on.enc 1
   G729AB_Decoder.exe tstseq1_vad_on.enc tstseq1_vad_on.dec
4b.
   Eample to run encoder with VAD Disable
   G729AB_Encoder.exe tstseq1.bin tstseq1_vad_on.enc 0
   G729AB_Decoder.exe tstseq1_vad_off.enc tstseq1_vad_off.dec

5a. 
   G.729AB Encoder API
   Int32 G729ABENC_CreateEncoder(void** g729abencHandle);
   Int32 G729ABENC_ResetEncoder (void* g729abencHandle);
   Int32 G729ABENC_SetEncoderParams(void* g729abencHandle,G729ABEncoderParam *EncParams);
   Int32 G729ABENC_EncodeFrame (void* g729abencHandle,Int16* srcBuf,Int32 srcLen,Int16 *dstBuf,Int32 *DstLen);
   Int32 G729ABENC_DeleteEncoder (void* g729abencHandle);

5b. 
   G.729AB Decoder API 
   Int32 G729ABDEC_CreateDecoder(void** g729abdecHandle);
   Int32 G729ABDEC_ResetDecoder (void* g729abdecHandle);
   Int32 G729ABDEC_SetDecoderParams(void* g729abdecHandle,tG729ABDecoderParam *DecParams);
   Int32 G729ABDEC_DecodeFrame (void* g729abdecHandle,Int16* srcBuf,Int32 srcLen,Int16 *dstBuf,Int32 *outSize);
   Int32 G729ABDEC_DeleteDecoder (void* g729abdecHandle);



