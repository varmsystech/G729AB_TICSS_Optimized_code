/*___________________________________________________________________________
 |                                                                           |
 |   Constants and Globals                                                   |
 |___________________________________________________________________________|
*/

#ifndef INCLUDE_BASICOP
#define INCLUDE_BASICOP
#include "typedef.h"
//extern Flag Overflow;
//extern Flag Carry;

#define MAX_32 (Word32)0x7fffffffL
#define MIN_32 (Word32)0x80000000L

#define MAX_16 (Word16)0x7fff
#define MIN_16 (Word16)0x8000
#define MINPWR        500
#define SCALE1		0x7eb851ecL //.99, Q31
#define SCALE2		0x0147ae15L //.01, Q31
/*___________________________________________________________________________
 |                                                                           |
 |   Operators prototypes                                                    |
 |___________________________________________________________________________|
*/
void audio_mixer(Word16 buffer_array[3][80], Word16 input2add, Word16 input_number, Word16 frame_size, Word32 minpwr, Word16 *out);
void zeros(Word16 *out, Word16 count);
void zerosl(Word32 *out, Word16 count);
void powerl_abs(Word32 *in, Word32 *power, Word16 count);
void   max_inp_power(Word32 *power_max, Word32 *power, Word16 number_input);
Word16 mult_s(Word16 var1, Word16 var2);
Word32 add_l(Word32 var1, Word32 var2);
Word32 abs_l(Word32 var1);
Word16 sature(Word32 L_var1);             /* Limit to 16 bits,    1 */
Word16 abs_s(Word16 var1);                /* Short abs,           1 */
Word16 shl(Word16 var1, Word16 var2);     /* Short shift left,    1 */
Word16 shr(Word16 var1, Word16 var2);     /* Short shift right,   1 */
Word16 negate(Word16 var1);               /* Short negate,        1 */
Word16 extract_h(Word32 L_var1);          /* Extract high,        1 */
Word32 L_add_c(Word32 L_var1, Word32 L_var2); /*Long add with c,  2 */
Word32 L_sub_c(Word32 L_var1, Word32 L_var2); /*Long sub with c,  2 */
Word32 L_negate(Word32 L_var1);               /* Long negate,     2 */
Word16 mult_r(Word16 var1, Word16 var2);  /* Mult with round,     2 */
Word32 L_shl(Word32 L_var1, Word16 var2); /* Long shift left,     2 */
Word32 L_shr(Word32 L_var1, Word16 var2); /* Long shift right,    2 */

Word16 shr_r(Word16 var1, Word16 var2);/* Shift right with round, 2 */
Word16 shr_rnegative(Word16 var1, Word16 var2);/* Shift right with round, 2 */
Word16 shl_negative(Word16 var1, Word16 var2);     /* Short shift left,    1 */
Word16 shr_negative(Word16 var1, Word16 var2);     /* Short shift right,   1 */
Word16 mac_r(Word32 L_var3, Word16 var1, Word16 var2);/* Mac with rounding, 2*/
Word16 msu_r(Word32 L_var3, Word16 var1, Word16 var2);/* Msu with rounding, 2*/
Word32 L_deposit_h(Word16 var1);       /* 16 bit var1 -> MSB,     2 */
Word32 L_deposit_l(Word16 var1);       /* 16 bit var1 -> LSB,     2 */
Word32 L_shr_r(Word32 L_var1, Word16 var2);/* Long shift right with round,  3*/
Word16 norm_s(Word16 var1);             /* Short norm,           15 */
Word16 div_s(Word16 var1, Word16 var2); /* Short division,       18 */
Word16 norm_l(Word32 L_var1);           /* Long norm,            30 */
/*----------modified Intrinsics ----------------------------------------*/

Word32 L_add(Word32 L_var1, Word32 L_var2);   /* Long add,        2 */
Word32 L_shr(Word32 L_var1, Word16 var2); /* Long shift right     2 */
Word32 L_mac(Word32 L_var3, Word16 var1, Word16 var2); /* Mac,    1 */
Word32 L_sub(Word32 L_var1, Word32 L_var2);   /* Long sub,        2 */
Word16 add(Word16 var1, Word16 var2);     /* Short add,           1 */
Word16 sub(Word16 var1, Word16 var2);    
Word16 extract_l(Word32 L_var1);          /* Extract low,         1 */
Word16 round(Word32 L_var1);              /* Round,               1 */
Word32 L_mult_smp(Word16 var1, Word16 var2);  /* Long mult,           1 */
Word32 L_mult(Word16 var1, Word16 var2);  /* Long mult,           1 */
Word16 mult(Word16 var1, Word16 var2);    /* Short mult,          1 */
Word32 L_msu(Word32 L_var3, Word16 var1, Word16 var2); /* Msu,    1 */
Word32 L_abs(Word32 L_var1);            /* Long abs,              3 */

#if 0
#define L_add(var1,var2)     (_sadd((var1),(var2)))             /* int sat addition       */
#define L_sub(var1,var2)     (_ssub((var1),(var2)))             /* int sat subtract       */
//#define L_sub_c(var1,var2)   L_add_c((var1),~(var2))            /* integer subtraction    */
#define L_negate(var1)    (_ssub(0,(var1)))               /* integer negation       */
#define L_deposit_h(var1) ((var1)<<16)                    /* put short in upper 16  */
#define L_deposit_l(var1) ((int)(var1))                   /* put short in lower 16  */
#define L_abs(var1)       (_abs(var1))                    /* int absolute value     */
#define L_mult(var1,var2)    (_smpy((var1),(var2)))             /* short sat mpy => 32    */
#define L_mac(var1,var2,c)   (_sadd((var1),L_mult(var2, c)))    /* saturated mpy & accum  */
#define L_macNs(var1,var2,c) L_add_c((var1),L_mult(var2,c))     /* mpy & accum w/o saturat*/
#define L_msu(var1,var2,c)   (_ssub((var1),L_mult(var2,c)))     /* saturated mpy & sub    */
#define L_msuNs(var1,var2,c) L_sub_c(var1,L_mult(var2,c))       /* mpy & sub w/o saturate */
#define L_shl(var1,var2)     ((var2) < 0 ? (var1) >> -(var2) : _sshl((var1),(var2)))
#define L_shr(var1,var2)     ((var2) < 0 ? _sshl((var1),-(var2)) : (var1) >> (var2))
#define L_shr_r(var1,var2)   (L_shr((var1),(var2)) + ((var2)>0 && (((var1) & (1<<((var2)-1))) != 0)))
#define abs_s(var1)       (_abs((var1)<<16)>>16)          /* short absolute value   */
#define add(var1,var2)       (_sadd((var1)<<16,(var2)<<16)>>16) /* short sat add          */
#define sub(var1,var2)       (_ssub((var1)<<16,(var2)<<16)>>16) /* short sat subtract     */
#define extract_h(var1)   ((unsigned)(var1)>>16)          /* extract upper 16 bits  */
#define extract_l(var1)   ((var1)&0xffff)                 /* extract lower 16 bits  */
#define round(var1)       extract_h(_sadd((var1),0x8000)) /* round                  */
#define mac_r(var1,var2,c)   (round(L_mac(var1,var2,c))) 	    /* mac w/ rounding        */
#define msu_r(var1,var2,c)   (round(L_msu(var1,var2,c)))        /* msu w/ rounding        */
#define mult_r(var1,var2)    (round(L_mult(var1,var2)))         /* sat mpy w/ round       */
#define mult(var1,var2)      (L_mult(var1,var2)>>16)            /* short sat mpy upper 16 */
#define norm_l(var1)      (_norm(var1))                   /* return NORM of int     */
#define norm_s(var1)      (_norm(var1)-16)                /* return NORM of short   */
#define negate(var1)      (_ssub(0, ((var1)<<16)) >> 16)  /* short sat negate       */
#define shl(var1,var2)       ((var2) < 0 ? (var1) >> -(var2) : (_sshl((var1),((var2)+16))>>16))
#define shr(var1,var2)       ((var2) < 0 ? (_sshl((var1),(-(var2)+16))>>16) : ((var1) >> (var2)))
#define shr_r(var1,var2)     ((var2) < 0 ? (_sshl((var1),(-(var2)+16))>>16) : (var2)==0 ? (var1) : \
                                    ((var1)+(1<<((var2)-1))) >> (var2))
#endif
#endif // #ifndef INCLUDE_BASICOP





