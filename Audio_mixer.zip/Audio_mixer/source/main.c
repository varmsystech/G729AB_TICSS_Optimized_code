/////////////////////////////////////////////////////////////////////////////////
//
//
// main.c  
//
// usage: Audio mixing program for 3 Audio Inputs at 8KHz frequency, frame size 10 msec
/////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "typedef.h"
#include "basic_op.h"

main(int argc,char *argv[])
{
  FILE *fp1,*fp2,*fp3,*fpout;

  Word16 number_input,sampling_freq,frame_size,temp;
  Word16 mixer_out[80];
  Word16 input_buffer[80];
  Word16 input_buffer_array[3][80];
  Word16 temp_input, l1, number_of_audio_input, i, lout;
  Word32 frame_number=0;
  Word16 end_input[3] = { 0, 0, 0 };
  Word16 input2add;
  Word32 max_nops_fix_per_frame=0;
  Word32 min_nops_fix_per_frame=(Word32) MAX_32;
  Word32 frame_max=0,frame_min=0;
  Word32 minpwr= (Word32) 0;

 
  input2add=3; // Number of Audio inputs 

  if(argc<4)
  {
	printf("Usage:\n");
	printf("- number of audio input =  3 \n");
	printf("- sampling frequency in kHz\n");
	printf("- frame size in 10 ms\n");
	exit(1);
  }

  number_input = 3; //;
  sampling_freq = 8; 
  frame_size = 80; // 80 Sample
  
  // minpwr is the threshold above which the mixer output is scaled
  minpwr=L_mult((Word16) MINPWR,80*3); // Number of sample * Number of Mixing input

  input2add=number_input; 

  if ((fp1 = fopen(argv[1], "rb")) == NULL)
 {
			printf("Error opening 1 input file\n");
			exit(1);
 }


  if ((fp2 = fopen(argv[2], "rb")) == NULL)
  {
			printf("Error opening 2 input file\n");
			exit(1);
  }

  if ((fp3 = fopen(argv[3], "rb")) == NULL)
  {
			printf("Error opening 3 input file\n");
			exit(1);
  }

  if ((fpout = fopen(argv[4], "wb")) == NULL)
  {
			printf("Error opening output file \n");
			exit(1);
  }

  // clear the input buffer
  zeros(input_buffer,frame_size);
  number_of_audio_input=0;
  for(i=0;i<3;i++)
	  number_of_audio_input = number_of_audio_input + end_input[i];

while (number_of_audio_input<number_input)
{
  for (i=0;i<input2add;i++)
  {
	for(l1=0;l1<frame_size;l1++)
		input_buffer_array[i][l1]=0;

  }

  temp_input=number_input;

  if(!end_input[0])
  {
  	  zeros(input_buffer,frame_size);
	  l1 = fread(input_buffer, sizeof(short), frame_size, fp1);
	  for(i=0;i<l1;i++)
		  input_buffer_array[0][i]=input_buffer[i];

	  if(l1<frame_size)
	  {
		  end_input[0]=1;
	  }

  }
  temp_input--;
 
  if(!end_input[1])
  {
      zeros(input_buffer,frame_size);

	  l1 = fread(input_buffer, sizeof(short), frame_size, fp2);
	  for(i=0;i<l1;i++)
		  input_buffer_array[1][i]=input_buffer[i];
	  if(l1<frame_size)
	  {
		  end_input[1]=1;
	  }
  }
  temp_input--;
 
  if(temp_input>0)
  {
	if(!end_input[2])
	{
			zeros(input_buffer,frame_size);

			l1 = fread(input_buffer, sizeof(short), frame_size, fp3);
			for(i=0;i<l1;i++)
				input_buffer_array[2][i] = input_buffer[i];

			if(l1<frame_size)
			{
				end_input[2]=1;
				for(i=l1;i<frame_size;i++)
					input_buffer_array[2][i] = 0;
			}
	}

  }

  audio_mixer(input_buffer_array, input2add, number_input, frame_size, minpwr, mixer_out);

  temp_input--;
  lout = fwrite(mixer_out, sizeof(short), frame_size, fpout);
  frame_number++;

  number_of_audio_input = 0;
  for(i=0;i<input2add;i++)
	  number_of_audio_input = number_of_audio_input + end_input[i];  // to end the process.
 }// end of while

 printf("Number of frames=%d\n",frame_number);
 printf("Number of input=%d\n",number_input);

}// end of main

