/////////////////////////////////////////////////////////////////////////////////
//
//
//				audio_mixer.c
/////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include "basic_op.h"
#include "oper_32b.h"

void audio_mixer(Word16 buffer_array[3][80], Word16 input2add, Word16 input_number, Word16 frame_size, Word32 minpower, Word16 *out)
{

	Word16 i,k;
	Word32 power[9];
	Word32 outl[80];
	Word32 out_power, power_in_max;
	static Word32 power0=0;
	Word32 temp_out; 
	Word32 temp;
    Word32 power_scale= 0x7FFFFFFFL;
	Word16 hi1,lo1,hi2,lo2,hi3,lo3,hi4,lo4,hi5,lo5;
	Word16 count;

	zerosl(outl,frame_size);

	for(i=0;i<input2add;i++)
    {
		power[i]=0;
		for(k=0;k<frame_size;k++)
		{
			temp=abs_l((Word32)buffer_array[i][k]);
			power[i]=add_l(power[i],temp);              
			outl[k]=add_l(outl[k],(Word32)buffer_array[i][k]);
		}
	}
    powerl_abs(outl,&out_power,frame_size);

    count=(Word16)0;

	max_inp_power(&power_in_max,power,input2add);

	if(  out_power>0 &&  out_power>= power_in_max) 
	{
		L_Extract(out_power,&hi1,&lo1);
		if(hi1<(Word16)0x3fff)
		{
			count=(Word16)0;
			temp=out_power;
	        while(temp<(Word32)0x3fff0000L)
			{
				temp=L_shl(temp,(Word16)1);
				count=add(count,1);
			}
			L_Extract(temp,&hi1,&lo1);
			power_scale = Div_32(power_in_max, hi1, lo1);
			power_scale = L_shl(power_scale, count);
		}
		else
			power_scale = Div_32(power_in_max, hi1, lo1);

	}
	else
	{
		power_scale=(Word32)0x7FFFFFFFL;
	}
 
  if(out_power<minpower)
  {
		power_scale=(Word32)0x7FFFFFFFL;
  }


  L_Extract(SCALE1, &hi3, &lo3);
  L_Extract(SCALE2, &hi4, &lo4);
  L_Extract(power_scale,&hi5,&lo5); 

  for(i=0;i<frame_size;i++)
  {

    L_Extract(power0,&hi2,&lo2);
   	power0=add_l(Mpy_32(hi2,lo2,hi3,lo3),Mpy_32(hi5,lo5,hi4,lo4)); 
	L_Extract(outl[i],&hi1,&lo1);
    L_Extract(power0,&hi2,&lo2);
	temp_out=Mpy_32(hi1,lo1,hi2,lo2);

	if(temp_out>= (Word32)MAX_16)
	{
		temp_out=(Word32)MAX_16;
	}


	else if(temp_out<=(Word32)MIN_16)
	{
		temp_out=(Word32)MIN_16;
	}
	out[i]=(Word16)temp_out;
  }

 
}